class Proposal {
  final String id;
  final String title;
  final String customer;
  final double amount;
  final String status;
  final DateTime date;
  final String description;
  final String request; // müşteri isteği

  Proposal({
    required this.id,
    required this.title,
    required this.customer,
    required this.amount,
    required this.status,
    required this.date,
    required this.description,
    required this.request, // yeni
  });
}
