/// Yardımcı fonksiyonlar.

class Helpers {
  static String formatDate(DateTime date) {
    return '${date.day}.${date.month}.${date.year}';
  }
}
