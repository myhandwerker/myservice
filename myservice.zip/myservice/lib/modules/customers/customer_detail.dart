import 'package:flutter/material.dart';
import '../../models/customer.dart';
import '../../utils/constants.dart';

class CustomerDetail extends StatelessWidget {
  final Customer customer;
  final void Function(Customer)? onEdit;

  const CustomerDetail({super.key, required this.customer, this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(customer.name),
        actions: [
          if (onEdit != null)
            IconButton(
              icon: const Icon(Icons.edit),
              tooltip: 'Düzenle',
              onPressed: () async {
                onEdit!(customer);
              },
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Card(
          color: AppColors.background,
          shape: RoundedRectangleBorder(
            side: const BorderSide(color: AppColors.yellowAccent, width: 2),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(32.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.person, size: 64, color: AppColors.yellowAccent),
                const SizedBox(height: 16),
                Text(
                  customer.name,
                  style: const TextStyle(fontSize: 24, color: AppColors.white),
                ),
                const SizedBox(height: 8),
                Text(
                  customer.email,
                  style: const TextStyle(
                    fontSize: 18,
                    color: AppColors.yellowAccent,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
