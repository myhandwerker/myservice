// lib/modules/customers/customer_model.dart

import 'customer_material_model.dart';
import 'customer_hour_model.dart';

class Customer {
  final String id;
  final String name;
  final String? email; // Nullable olarak işaretlendi
  final String phone;
  final String address;
  final String? customerNumber; // taxId yerine customerNumber
  final String? notes;
  final List<CustomerMaterial> materials;
  final List<CustomerHour> workHours;

  Customer({
    required this.id,
    required this.name,
    this.email, // Nullable olduğu için required kaldırıldı
    required this.phone,
    required this.address,
    this.customerNumber, // Nullable olduğu için required kaldırıldı
    this.notes,
    this.materials = const [],
    this.workHours = const [],
  });

  // copyWith metodu (eğer model değişirse)
  Customer copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? address,
    String? customerNumber,
    String? notes,
    List<CustomerMaterial>? materials,
    List<CustomerHour>? workHours,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      customerNumber: customerNumber ?? this.customerNumber,
      notes: notes ?? this.notes,
      materials: materials ?? this.materials,
      workHours: workHours ?? this.workHours,
    );
  }

  // From JSON
  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      phone: json['phone'],
      address: json['address'],
      customerNumber: json['customerNumber'], // taxId yerine customerNumber
      notes: json['notes'],
      materials: (json['materials'] as List<dynamic>?)
              ?.map((e) => CustomerMaterial.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      workHours: (json['workHours'] as List<dynamic>?)
              ?.map((e) => CustomerHour.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  // To JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
      'customerNumber': customerNumber, // taxId yerine customerNumber
      'notes': notes,
      'materials': materials.map((e) => e.toJson()).toList(),
      'workHours': workHours.map((e) => e.toJson()).toList(),
    };
  }
}
