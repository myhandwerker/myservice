// lib/modules/customers/work_entry_model.dart
import 'package:flutter/material.dart';

class WorkEntry {
  final String id;
  final DateTime date;
  final TimeOfDay startTime;
  final TimeOfDay endTime;
  final int breakMinutes;
  final double kilometers;
  final double kilometerRate;
  final String workLocation;

  WorkEntry({
    required this.id,
    required this.date,
    required this.startTime,
    required this.endTime,
    this.breakMinutes = 0,
    this.kilometers = 0.0,
    this.kilometerRate = 0.0,
    required this.workLocation,
  });

  int get durationMinutes {
    final startDateTime = DateTime(
      date.year,
      date.month,
      date.day,
      startTime.hour,
      startTime.minute,
    );
    final endDateTime = DateTime(
      date.year,
      date.month,
      date.day,
      endTime.hour,
      endTime.minute,
    );

    if (endDateTime.isBefore(startDateTime)) {
      return (endDateTime
                  .add(const Duration(days: 1))
                  .difference(startDateTime)
                  .inMinutes -
              breakMinutes)
          .clamp(0, double.infinity)
          .toInt();
    }
    return (endDateTime.difference(startDateTime).inMinutes - breakMinutes)
        .clamp(0, double.infinity)
        .toInt();
  }

  double get kilometerCost => kilometers * kilometerRate;

  WorkEntry copyWith({
    String? id,
    DateTime? date,
    TimeOfDay? startTime,
    TimeOfDay? endTime,
    int? breakMinutes,
    double? kilometers,
    double? kilometerRate,
    String? workLocation,
  }) {
    return WorkEntry(
      id: id ?? this.id,
      date: date ?? this.date,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      breakMinutes: breakMinutes ?? this.breakMinutes,
      kilometers: kilometers ?? this.kilometers,
      kilometerRate: kilometerRate ?? this.kilometerRate,
      workLocation: workLocation ?? this.workLocation,
    );
  }

  factory WorkEntry.fromJson(Map<String, dynamic> json) {
    return WorkEntry(
      id: json['id'],
      date: DateTime.parse(json['date']),
      startTime: TimeOfDay(
        hour: json['startTimeHour'],
        minute: json['startTimeMinute'],
      ),
      endTime: TimeOfDay(
        hour: json['endTimeHour'],
        minute: json['endTimeMinute'],
      ),
      breakMinutes: json['breakMinutes'] ?? 0,
      kilometers: (json['kilometers'] as num?)?.toDouble() ?? 0.0,
      kilometerRate: (json['kilometerRate'] as num?)?.toDouble() ?? 0.0,
      workLocation: json['workLocation'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'startTimeHour': startTime.hour,
      'startTimeMinute': startTime.minute,
      'endTimeHour': endTime.hour,
      'endTimeMinute': endTime.minute,
      'breakMinutes': breakMinutes,
      'kilometers': kilometers,
      'kilometerRate': kilometerRate,
      'workLocation': workLocation,
    };
  }
}
