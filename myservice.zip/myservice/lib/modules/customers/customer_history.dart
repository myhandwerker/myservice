/// Müşterinin geçmişine (işler, teklifler, faturalar) dair kayıtları gösteren sayfa.

import 'package:flutter/material.dart';

class CustomerHistory extends StatelessWidget {
  const CustomerHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Müşteri Geçmişi')),
      body: const Center(child: Text('Burada müşteri geçmişi görüntülenecek')),
    );
  }
}
