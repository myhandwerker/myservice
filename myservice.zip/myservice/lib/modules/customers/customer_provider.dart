// lib/modules/customers/customer_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert'; // json encode/decode için

import 'customer_model.dart'; // Customer modelini import et

class CustomerProvider with ChangeNotifier {
  List<Customer> _customers = [];
  bool _isLoading = true;

  CustomerProvider() {
    _loadCustomers();
  }

  List<Customer> get customers => _customers;
  bool get isLoading => _isLoading;

  Future<void> _loadCustomers() async {
    _isLoading = true;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    final String? customersJson = prefs.getString('customers');

    if (customersJson != null) {
      try {
        final List<dynamic> jsonList = json.decode(customersJson);
        _customers = jsonList.map((json) => Customer.fromJson(json)).toList();
      } catch (e) {
        print('Error decoding customers from SharedPreferences: $e');
        _customers =
            _getInitialCustomers(); // Hata olursa başlangıç verilerini yükle
      }
    } else {
      _customers =
          _getInitialCustomers(); // Hiç veri yoksa başlangıç verilerini yükle
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> _saveCustomers() async {
    final prefs = await SharedPreferences.getInstance();
    final String customersJson =
        json.encode(_customers.map((customer) => customer.toJson()).toList());
    await prefs.setString('customers', customersJson);
  }

  void addCustomer(Customer customer) {
    _customers.add(customer);
    _saveCustomers();
    notifyListeners();
  }

  void updateCustomer(Customer updatedCustomer) {
    final index = _customers.indexWhere((c) => c.id == updatedCustomer.id);
    if (index != -1) {
      _customers[index] = updatedCustomer;
      _saveCustomers();
      notifyListeners();
    }
  }

  void deleteCustomer(String customerId) {
    _customers.removeWhere((c) => c.id == customerId);
    _saveCustomers();
    notifyListeners();
  }

  // Başlangıç için birkaç örnek müşteri
  List<Customer> _getInitialCustomers() {
    return [
      Customer(
        id: '1',
        name: 'Müşteri A',
        address: 'Örnek Sok. 1, İstanbul',
        phone: '5551112233',
        email: 'musteria@example.com',
        customerNumber: 'CUST-001',
      ),
      Customer(
        id: '2',
        name: 'Müşteri B İnşaat',
        address: 'Deneme Cad. 2, Ankara',
        phone: '5554445566',
        email: 'musterib@example.com',
        customerNumber: 'CUST-002',
      ),
      Customer(
        id: '3',
        name: 'Müşteri C Teknoloji',
        address: 'Bilişim Mah. 3, İzmir',
        phone: '5557778899',
        customerNumber: 'CUST-003',
      ),
    ];
  }
}
