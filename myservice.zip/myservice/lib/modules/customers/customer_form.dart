// lib/modules/customers/customer_form.dart

import 'package:flutter/material.dart';
import '../../utils/constants.dart';
import 'customer_model.dart';
import 'customer_material_model.dart';
import 'customer_hour_model.dart';

class CustomerForm extends StatefulWidget {
  final Customer? initialCustomer; // Düzenleme için

  const CustomerForm({super.key, this.initialCustomer});

  @override
  State<CustomerForm> createState() => _CustomerFormState();
}

class _CustomerFormState extends State<CustomerForm> {
  final _formKey = GlobalKey<FormState>();
  late String _name;
  late String _email;
  late String _phone;
  late String _address;
  late String? _taxId; // Yeni eklendi
  late String? _notes; // Yeni eklendi
  late List<CustomerMaterial> _materials; // Yeni eklendi
  late List<CustomerHour> _workHours; // Yeni eklendi

  @override
  void initState() {
    super.initState();
    _name = widget.initialCustomer?.name ?? '';
    _email = widget.initialCustomer?.email ?? '';
    _phone = widget.initialCustomer?.phone ?? '';
    _address = widget.initialCustomer?.address ?? '';
    _taxId = widget.initialCustomer?.taxId;
    _notes = widget.initialCustomer?.notes;
    _materials = List<CustomerMaterial>.from(
      widget.initialCustomer?.materials ?? [],
    );
    _workHours = List<CustomerHour>.from(
      widget.initialCustomer?.workHours ?? [],
    );
  }

  // Yeni malzeme eklemek için yardımcı metot
  void _addMaterial() {
    setState(() {
      _materials.add(
        CustomerMaterial(
          id: DateTime.now().millisecondsSinceEpoch.toString(), // Basit bir ID
          name: '',
          quantity: 0.0,
          unit: '',
          unitPrice: 0.0,
        ),
      );
    });
  }

  // Yeni işçilik saati eklemek için yardımcı metot
  void _addWorkHour() {
    setState(() {
      _workHours.add(
        CustomerHour(
          id: DateTime.now().millisecondsSinceEpoch.toString(), // Basit bir ID
          description: '',
          quantity: 0.0,
          unit: '',
          unitPrice: 0.0,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.background,
      title: Text(
        widget.initialCustomer == null ? 'Yeni Müşteri' : 'Müşteri Düzenle',
        style: const TextStyle(color: AppColors.yellowAccent),
      ),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                initialValue: _name,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'Ad Soyad',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                validator: (value) =>
                    (value == null || value.isEmpty) ? 'Ad giriniz' : null,
                onSaved: (value) => _name = value ?? '',
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _email,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'E-posta',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                validator: (value) => (value == null || !value.contains('@'))
                    ? 'Geçerli e-posta giriniz'
                    : null,
                onSaved: (value) => _email = value ?? '',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _phone,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'Telefon',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                validator: (value) => (value == null || value.length < 10)
                    ? 'Telefon giriniz'
                    : null,
                onSaved: (value) => _phone = value ?? '',
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _address,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'Adres',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                validator: (value) =>
                    (value == null || value.isEmpty) ? 'Adres giriniz' : null,
                onSaved: (value) => _address = value ?? '',
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _taxId,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'Vergi Numarası (Steuernummer)',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                onSaved: (value) => _taxId = value,
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _notes,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(
                  labelText: 'Ek Notlar',
                  labelStyle: TextStyle(color: AppColors.textSecondary),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.yellowAccent),
                  ),
                ),
                onSaved: (value) => _notes = value,
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              // Malzeme Listesi Kısmı
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Müşteriye Özel Malzemeler',
                  style: AppTextStyles.subtitle.copyWith(
                    color: AppColors.yellowAccent,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              if (_materials.isEmpty)
                Text(
                  'Malzeme tanımlanmamış.',
                  style: AppTextStyles.body.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ..._materials.asMap().entries.map((entry) {
                final int index = entry.key;
                final CustomerMaterial material = entry.value;
                return Card(
                  color: AppColors.surface, // Yeni eklenen surface rengi
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        TextFormField(
                          initialValue: material.name,
                          style: const TextStyle(color: AppColors.white),
                          decoration: const InputDecoration(
                            labelText: 'Malzeme Adı',
                            labelStyle: TextStyle(
                              color: AppColors.textSecondary,
                            ),
                            isDense: true,
                          ),
                          onChanged: (value) {
                            _materials[index] = material.copyWith(name: value);
                          },
                          validator: (value) =>
                              value!.isEmpty ? 'Malzeme adı gerekli' : null,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: TextFormField(
                                initialValue: material.quantity.toString(),
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Miktar',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  _materials[index] = material.copyWith(
                                    quantity: double.tryParse(value),
                                  );
                                },
                                validator: (value) => (value == null ||
                                        double.tryParse(value) == null)
                                    ? 'Miktar giriniz'
                                    : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 1,
                              child: TextFormField(
                                initialValue: material.unit,
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Birim',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                onChanged: (value) {
                                  _materials[index] = material.copyWith(
                                    unit: value,
                                  );
                                },
                                validator: (value) =>
                                    value!.isEmpty ? 'Birim gerekli' : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 2,
                              child: TextFormField(
                                initialValue: material.unitPrice.toString(),
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Birim Fiyat',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  _materials[index] = material.copyWith(
                                    unitPrice: double.tryParse(value),
                                  );
                                },
                                validator: (value) => (value == null ||
                                        double.tryParse(value) == null)
                                    ? 'Fiyat giriniz'
                                    : null,
                              ),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.remove_circle,
                                color: AppColors.error,
                              ),
                              onPressed: () {
                                setState(() {
                                  _materials.removeAt(index);
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _addMaterial,
                  icon: const Icon(Icons.add, color: AppColors.accent),
                  label: Text(
                    'Malzeme Ekle',
                    style: AppTextStyles.body.copyWith(color: AppColors.accent),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // İşçilik Saatleri Listesi Kısmı
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Müşteriye Özel İşçilik Saatleri',
                  style: AppTextStyles.subtitle.copyWith(
                    color: AppColors.yellowAccent,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              if (_workHours.isEmpty)
                Text(
                  'İşçilik saati tanımlanmamış.',
                  style: AppTextStyles.body.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ..._workHours.asMap().entries.map((entry) {
                final int index = entry.key;
                final CustomerHour hour = entry.value;
                return Card(
                  color: AppColors.surface,
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        TextFormField(
                          initialValue: hour.description,
                          style: const TextStyle(color: AppColors.white),
                          decoration: const InputDecoration(
                            labelText: 'Açıklama',
                            labelStyle: TextStyle(
                              color: AppColors.textSecondary,
                            ),
                            isDense: true,
                          ),
                          onChanged: (value) {
                            _workHours[index] = hour.copyWith(
                              description: value,
                            );
                          },
                          validator: (value) =>
                              value!.isEmpty ? 'Açıklama gerekli' : null,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: TextFormField(
                                initialValue: hour.quantity.toString(),
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Miktar',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  _workHours[index] = hour.copyWith(
                                    quantity: double.tryParse(value),
                                  );
                                },
                                validator: (value) => (value == null ||
                                        double.tryParse(value) == null)
                                    ? 'Miktar giriniz'
                                    : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 1,
                              child: TextFormField(
                                initialValue: hour.unit,
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Birim',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                onChanged: (value) {
                                  _workHours[index] = hour.copyWith(
                                    unit: value,
                                  );
                                },
                                validator: (value) =>
                                    value!.isEmpty ? 'Birim gerekli' : null,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              flex: 2,
                              child: TextFormField(
                                initialValue: hour.unitPrice.toString(),
                                style: const TextStyle(color: AppColors.white),
                                decoration: const InputDecoration(
                                  labelText: 'Birim Fiyat',
                                  labelStyle: TextStyle(
                                    color: AppColors.textSecondary,
                                  ),
                                  isDense: true,
                                ),
                                keyboardType: TextInputType.number,
                                onChanged: (value) {
                                  _workHours[index] = hour.copyWith(
                                    unitPrice: double.tryParse(value),
                                  );
                                },
                                validator: (value) => (value == null ||
                                        double.tryParse(value) == null)
                                    ? 'Fiyat giriniz'
                                    : null,
                              ),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.remove_circle,
                                color: AppColors.error,
                              ),
                              onPressed: () {
                                setState(() {
                                  _workHours.removeAt(index);
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _addWorkHour,
                  icon: const Icon(Icons.add, color: AppColors.accent),
                  label: Text(
                    'İşçilik Saati Ekle',
                    style: AppTextStyles.body.copyWith(color: AppColors.accent),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          child: const Text(
            'İptal',
            style: TextStyle(color: AppColors.yellowAccent),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.yellowAccent,
            foregroundColor: AppColors.background,
          ),
          child: Text(widget.initialCustomer == null ? 'Ekle' : 'Kaydet'),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              _formKey.currentState!.save();
              final updatedCustomer = Customer(
                id: widget.initialCustomer?.id ??
                    DateTime.now().millisecondsSinceEpoch.toString(),
                name: _name,
                email: _email,
                phone: _phone,
                address: _address,
                taxId: _taxId, // Yeni eklendi
                notes: _notes, // Yeni eklendi
                materials: _materials, // Yeni eklendi
                workHours: _workHours, // Yeni eklendi
              );
              Navigator.of(context).pop(updatedCustomer);
            }
          },
        ),
      ],
    );
  }
}
