// lib/modules/customers/customer_hour_model.dart
import 'package:uuid/uuid.dart';
import 'work_entry_model.dart'; // WorkEntry modelini import et

class CustomerHour {
  final String id;
  String description;
  double ratePerHour;
  List<WorkEntry> workEntries; // Bağlantılı çalışma girişleri

  CustomerHour({
    String? id,
    required this.description,
    required this.ratePerHour,
    List<WorkEntry>? workEntries,
  })  : id = id ?? const Uuid().v4(),
        workEntries = workEntries ?? [];

  double get totalHours =>
      workEntries.fold(0.0, (sum, entry) => sum + entry.hours);
  double get totalCost => totalHours * ratePerHour;

  factory CustomerHour.fromJson(Map<String, dynamic> json) {
    return CustomerHour(
      id: json['id'],
      description: json['description'],
      ratePerHour: json['ratePerHour']?.toDouble() ?? 0.0,
      workEntries: (json['workEntries'] as List<dynamic>?)
              ?.map((e) => WorkEntry.fromJson(e))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'description': description,
      'ratePerHour': ratePerHour,
      'workEntries': workEntries.map((e) => e.toJson()).toList(),
    };
  }

  CustomerHour copyWith({
    String? id,
    String? description,
    double? ratePerHour,
    List<WorkEntry>? workEntries,
  }) {
    return CustomerHour(
      id: id ?? this.id,
      description: description ?? this.description,
      ratePerHour: ratePerHour ?? this.ratePerHour,
      workEntries: workEntries ?? this.workEntries,
    );
  }
}
