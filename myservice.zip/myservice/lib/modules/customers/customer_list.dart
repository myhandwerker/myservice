import 'package:flutter/material.dart';
import '../../models/customer.dart';
import '../../utils/constants.dart';

class CustomerList extends StatefulWidget {
  const CustomerList({super.key});

  @override
  State<CustomerList> createState() => _CustomerListState();
}

class _CustomerListState extends State<CustomerList> {
  final TextEditingController _searchController = TextEditingController();
  List<Customer> customers = [
    Customer(
      id: '1',
      name: 'Ali Yılmaz',
      email: 'ali@email.com',
      phone: '05551234567',
      address: 'İstanbul',
      company: 'Yılmaz Ltd.',
    ),
    Customer(
      id: '2',
      name: 'Ayşe Demir',
      email: 'ayse@email.com',
      phone: '05557654321',
      address: 'Ankara',
      company: 'Demir İnşaat',
    ),
    Customer(
      id: '3',
      name: 'Mehmet Can',
      email: 'mehmet@email.com',
      phone: '05559876543',
      address: 'İzmir',
      company: 'Can Elektrik',
    ),
  ];
  List<Customer> filteredCustomers = [];

  @override
  void initState() {
    super.initState();
    filteredCustomers = List.from(customers);
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        filteredCustomers = List.from(customers);
      } else {
        filteredCustomers = customers
            .where(
              (c) =>
                  c.name.toLowerCase().contains(query) ||
                  c.email.toLowerCase().contains(query) ||
                  c.phone.toLowerCase().contains(query) ||
                  c.address.toLowerCase().contains(query) ||
                  c.company.toLowerCase().contains(query),
            )
            .toList();
      }
    });
  }

  void _addCustomer() async {
    final Customer? newCustomer = await showDialog(
      context: context,
      builder: (context) => CustomerForm(),
    );
    if (newCustomer != null) {
      setState(() {
        customers.add(newCustomer);
        _onSearchChanged();
      });
    }
  }

  void _editCustomer(Customer customer) async {
    final Customer? updatedCustomer = await showDialog(
      context: context,
      builder: (context) => CustomerForm(initialCustomer: customer),
    );
    if (updatedCustomer != null) {
      setState(() {
        final idx = customers.indexWhere((c) => c.id == customer.id);
        customers[idx] = updatedCustomer;
        _onSearchChanged();
      });
    }
  }

  void _removeCustomer(Customer customer) {
    setState(() {
      customers.removeWhere((c) => c.id == customer.id);
      _onSearchChanged();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Müşteri silindi: ${customer.name}"),
        backgroundColor: AppColors.yellowAccent,
        action: SnackBarAction(
          label: "Geri Al",
          textColor: AppColors.background,
          onPressed: () {
            setState(() {
              customers.add(customer);
              _onSearchChanged();
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: AppColors.white),
              decoration: InputDecoration(
                hintText: "Müşteri, e-posta, telefon, adres veya şirket ara",
                hintStyle: const TextStyle(color: Colors.white70),
                prefixIcon: const Icon(
                  Icons.search,
                  color: AppColors.yellowAccent,
                ),
                filled: true,
                fillColor: AppColors.background,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.yellowAccent),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.yellowAccent),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: AppColors.yellowAccent,
                    width: 2,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: filteredCustomers.isEmpty
                ? const Center(
                    child: Text(
                      "Kayıtlı müşteri yok.",
                      style: TextStyle(color: Colors.white54, fontSize: 18),
                    ),
                  )
                : ListView.separated(
                    itemCount: filteredCustomers.length,
                    separatorBuilder: (_, __) =>
                        Divider(color: AppColors.yellowAccent),
                    itemBuilder: (context, i) {
                      final c = filteredCustomers[i];
                      return Dismissible(
                        key: Key(c.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: Colors.red,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: const Icon(
                            Icons.delete,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                        onDismissed: (_) => _removeCustomer(c),
                        child: ListTile(
                          leading: Icon(
                            Icons.person,
                            color: AppColors.yellowAccent,
                          ),
                          title: Text(
                            c.name,
                            style: const TextStyle(color: AppColors.white),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'E-posta: ${c.email}',
                                style: const TextStyle(color: Colors.white70),
                              ),
                              Text(
                                'Telefon: ${c.phone}',
                                style: const TextStyle(color: Colors.white70),
                              ),
                              Text(
                                'Adres: ${c.address}',
                                style: const TextStyle(color: Colors.white70),
                              ),
                              Text(
                                'Şirket: ${c.company}',
                                style: const TextStyle(color: Colors.white70),
                              ),
                            ],
                          ),
                          trailing: Icon(
                            Icons.edit,
                            color: AppColors.yellowAccent,
                          ),
                          onTap: () => _editCustomer(c),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.yellowAccent,
        foregroundColor: AppColors.background,
        onPressed: _addCustomer,
        tooltip: "Müşteri Ekle",
        child: const Icon(Icons.add),
      ),
    );
  }
}

class CustomerForm extends StatefulWidget {
  final Customer? initialCustomer;
  const CustomerForm({super.key, this.initialCustomer});

  @override
  State<CustomerForm> createState() => _CustomerFormState();
}

class _CustomerFormState extends State<CustomerForm> {
  final _formKey = GlobalKey<FormState>();
  late String name;
  late String email;
  late String phone;
  late String address;
  late String company;

  @override
  void initState() {
    super.initState();
    name = widget.initialCustomer?.name ?? '';
    email = widget.initialCustomer?.email ?? '';
    phone = widget.initialCustomer?.phone ?? '';
    address = widget.initialCustomer?.address ?? '';
    company = widget.initialCustomer?.company ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppColors.background,
      title: Text(
        widget.initialCustomer == null ? "Yeni Müşteri" : "Müşteri Düzenle",
        style: const TextStyle(color: AppColors.yellowAccent),
      ),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                initialValue: name,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Ad Soyad"),
                validator: (value) =>
                    (value == null || value.isEmpty) ? "Ad giriniz" : null,
                onSaved: (value) => name = value ?? '',
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: email,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "E-posta"),
                validator: (value) => (value == null || !value.contains('@'))
                    ? "Geçerli e-posta giriniz"
                    : null,
                onSaved: (value) => email = value ?? '',
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: phone,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Telefon"),
                validator: (value) => (value == null || value.length < 10)
                    ? "Telefon giriniz"
                    : null,
                onSaved: (value) => phone = value ?? '',
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: address,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Adres"),
                validator: (value) =>
                    (value == null || value.isEmpty) ? "Adres giriniz" : null,
                onSaved: (value) => address = value ?? '',
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: company,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Şirket"),
                validator: (value) =>
                    (value == null || value.isEmpty) ? "Şirket giriniz" : null,
                onSaved: (value) => company = value ?? '',
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          child: const Text(
            "İptal",
            style: TextStyle(color: AppColors.yellowAccent),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.yellowAccent,
            foregroundColor: AppColors.background,
          ),
          child: Text(widget.initialCustomer == null ? "Ekle" : "Kaydet"),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              _formKey.currentState!.save();
              final customer = Customer(
                id: widget.initialCustomer?.id ??
                    DateTime.now().millisecondsSinceEpoch.toString(),
                name: name,
                email: email,
                phone: phone,
                address: address,
                company: company,
              );
              Navigator.of(context).pop(customer);
            }
          },
        ),
      ],
    );
  }
}
