import 'package:flutter/material.dart';
import '../tasks/task_model.dart';

// Eğer Customer modelini başka yerde tanımladıysan buradan import et.
class Customer {
  final String id;
  final String name;
  Customer({required this.id, required this.name});
}

class CustomerDetailPage extends StatefulWidget {
  final Customer customer;
  final List<Task> allTasks;

  const CustomerDetailPage({
    super.key, // use super.key instead of key
    required this.customer,
    required this.allTasks,
  });

  @override
  State<CustomerDetailPage> createState() => _CustomerDetailPageState();
}

class _CustomerDetailPageState extends State<CustomerDetailPage> {
  List<Task> get customerTasks =>
      widget.allTasks.where((t) => t.customerId == widget.customer.id).toList();

  void _addTask(Task newTask) {
    setState(() {
      widget.allTasks.add(newTask);
    });
  }

  @override
  Widget build(BuildContext context) {
    final customer = widget.customer;
    return Scaffold(
      appBar: AppBar(title: Text("${customer.name} Detay")),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            title: Text(customer.name),
            subtitle: Text("Müşteri ID: ${customer.id}"),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              "Görevler",
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          Expanded(
            child: customerTasks.isEmpty
                ? const Center(child: Text("Bu müşteriye ait görev yok."))
                : ListView.builder(
                    itemCount: customerTasks.length,
                    itemBuilder: (context, i) {
                      final task = customerTasks[i];
                      return ListTile(
                        leading: Icon(
                          task.status == TaskStatus.done
                              ? Icons.check_circle
                              : task.status == TaskStatus.inProgress
                              ? Icons.timelapse
                              : Icons.radio_button_unchecked,
                        ),
                        title: Text(task.title),
                        subtitle: Text(task.description),
                        trailing: Text(
                          "${task.date.day}.${task.date.month}.${task.date.year}",
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newTask = await Navigator.push<Task>(
            context,
            MaterialPageRoute(
              builder: (_) => TaskForm(
                initialCustomerId:
                    customer.id, // Formda doğrudan bu müşteri seçili gelir.
              ),
            ),
          );
          if (newTask != null) _addTask(newTask);
        },
        child: const Icon(Icons.add),
        tooltip: "Bu müşteriye görev ekle",
      ),
    );
  }
}

class TaskForm extends StatelessWidget {
  final String? initialCustomerId;
  const TaskForm({Key? key, this.initialCustomerId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Use initialCustomerId as needed
    return Scaffold(
      appBar: AppBar(title: const Text('Görev Ekle')),
      body: Center(child: Text('Seçili müşteri: $initialCustomerId')),
    );
  }
}
