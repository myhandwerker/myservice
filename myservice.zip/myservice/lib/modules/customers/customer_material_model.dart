// lib/modules/customers/customer_material_model.dart
import 'package:uuid/uuid.dart';

class CustomerMaterial {
  final String id;
  String name;
  double quantity;
  String unit;
  double unitPrice;

  CustomerMaterial({
    String? id,
    required this.name,
    required this.quantity,
    required this.unit,
    required this.unitPrice,
  }) : id = id ?? const Uuid().v4();

  double get total => quantity * unitPrice;

  factory CustomerMaterial.fromJson(Map<String, dynamic> json) {
    return CustomerMaterial(
      id: json['id'],
      name: json['name'],
      quantity: json['quantity']?.toDouble() ?? 0.0,
      unit: json['unit'],
      unitPrice: json['unitPrice']?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'quantity': quantity,
      'unit': unit,
      'unitPrice': unitPrice,
    };
  }

  CustomerMaterial copyWith({
    String? id,
    String? name,
    double? quantity,
    String? unit,
    double? unitPrice,
  }) {
    return CustomerMaterial(
      id: id ?? this.id,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      unitPrice: unitPrice ?? this.unitPrice,
    );
  }
}
