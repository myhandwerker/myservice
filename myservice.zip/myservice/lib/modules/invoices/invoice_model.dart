// lib/modules/invoices/invoice_model.dart
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart'; // Tarih formatlama için

import '../customers/customer_model.dart'; // Müşteri modelini import et
import '../customers/customer_material_model.dart'; // Materyal modelini import et
import '../customers/customer_hour_model.dart'; // Saat modeli import et

enum InvoiceStatus {
  draft,
  sent,
  paid,
  overdue,
  cancelled,
}

class InvoiceItem {
  final String id;
  String description;
  double quantity;
  String unit;
  double unitPrice;

  InvoiceItem({
    String? id,
    required this.description,
    required this.quantity,
    required this.unit,
    required this.unitPrice,
  }) : id = id ?? const Uuid().v4();

  double get total => quantity * unitPrice;

  factory InvoiceItem.fromJson(Map<String, dynamic> json) {
    return InvoiceItem(
      id: json['id'],
      description: json['description'],
      quantity: json['quantity']?.toDouble() ?? 0.0,
      unit: json['unit'],
      unitPrice: json['unitPrice']?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'description': description,
      'quantity': quantity,
      'unit': unit,
      'unitPrice': unitPrice,
    };
  }
}

class Invoice {
  final String id;
  String invoiceNumber;
  final Customer customer; // Fatura hangi müşteriye ait
  DateTime issueDate;
  DateTime dueDate;
  InvoiceStatus status;
  List<InvoiceItem>
      items; // Fatura kalemleri (materyal, çalışma saati vb. olabilir)
  double? discount; // Yüzde olarak indirim
  String? notes; // Ek notlar

  Invoice({
    String? id,
    required this.invoiceNumber,
    required this.customer,
    required this.issueDate,
    required this.dueDate,
    this.status = InvoiceStatus.draft,
    List<InvoiceItem>? items,
    this.discount,
    this.notes,
  })  : id = id ?? const Uuid().v4(),
        items = items ?? [];

  double get subtotal => items.fold(0.0, (sum, item) => sum + item.total);

  double get totalAmount {
    double total = subtotal;
    if (discount != null && discount! > 0 && discount! <= 100) {
      total -= (total * discount! / 100);
    }
    return total;
  }

  // Customer nesnesinin doğrudan JSON içinde saklanmaması için bu factory metodu
  // customerProvider'dan Customer nesnesini alarak yeniden oluşturulacak.
  factory Invoice.fromJson(Map<String, dynamic> json, Customer customer) {
    return Invoice(
      id: json['id'],
      invoiceNumber: json['invoiceNumber'],
      customer: customer, // Dışarıdan sağlanan Customer nesnesi
      issueDate: DateTime.parse(json['issueDate']),
      dueDate: DateTime.parse(json['dueDate']),
      status: InvoiceStatus.values.firstWhere(
          (e) => e.toString() == json['status'],
          orElse: () => InvoiceStatus.draft),
      items: (json['items'] as List<dynamic>?)
              ?.map((e) => InvoiceItem.fromJson(e))
              .toList() ??
          [],
      discount: json['discount']?.toDouble(),
      notes: json['notes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'invoiceNumber': invoiceNumber,
      'customerId': customer.id, // Sadece müşteri ID'sini sakla
      'issueDate': issueDate.toIso8601String(),
      'dueDate': dueDate.toIso8601String(),
      'status': status.toString(),
      'items': items.map((e) => e.toJson()).toList(),
      'discount': discount,
      'notes': notes,
    };
  }

  Invoice copyWith({
    String? id,
    String? invoiceNumber,
    Customer? customer,
    DateTime? issueDate,
    DateTime? dueDate,
    InvoiceStatus? status,
    List<InvoiceItem>? items,
    double? discount,
    String? notes,
  }) {
    return Invoice(
      id: id ?? this.id,
      invoiceNumber: invoiceNumber ?? this.invoiceNumber,
      customer: customer ?? this.customer,
      issueDate: issueDate ?? this.issueDate,
      dueDate: dueDate ?? this.dueDate,
      status: status ?? this.status,
      items: items ?? this.items,
      discount: discount ?? this.discount,
      notes: notes ?? this.notes,
    );
  }
}
