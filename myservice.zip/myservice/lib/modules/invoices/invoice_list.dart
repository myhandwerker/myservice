// lib/modules/invoices/invoice_list.dart

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart'; // Tarih formatlama için
import '../../utils/constants.dart';
import '../customers/customer_model.dart';
import '../customers/customer_material_model.dart';
import '../customers/customer_hour_model.dart';
import 'invoice_model.dart';
import 'invoice_form.dart';

class InvoiceList extends StatefulWidget {
  final Customer customer; // Bu fatura listesi belirli bir müşteriye ait olacak
  const InvoiceList({super.key, required this.customer});

  @override
  State<InvoiceList> createState() => _InvoiceListState();
}

class _InvoiceListState extends State<InvoiceList> {
  final TextEditingController _searchController = TextEditingController();
  List<Invoice> invoices = []; // Bu müşteriye ait faturalar
  List<Invoice> filteredInvoices = [];

  @override
  void initState() {
    super.initState();
    // Örnek faturalar (test amaçlı)
    final uuid = const Uuid();
    invoices = [
      Invoice(
        id: uuid.v4(),
        customer: widget.customer,
        invoiceNumber:
            'INV-${DateFormat('yyyyMMdd').format(DateTime.now())}-001',
        invoiceDate: DateTime.now().subtract(const Duration(days: 30)),
        dueDate: DateTime.now().subtract(const Duration(days: 16)),
        items: [
          InvoiceItem(
            id: uuid.v4(),
            description: 'Laminat Döşeme',
            quantity: 20.0,
            unitPrice: 15.0,
            type: 'material',
            sourceId: widget.customer.materials.isNotEmpty
                ? widget.customer.materials[0].id
                : null,
          ),
          InvoiceItem(
            id: uuid.v4(),
            description: 'Genel Montaj Hizmeti',
            quantity: 8.0, // Örnek olarak sabit bir saat verelim
            unitPrice: 45.0, // Saatlik ücret
            type: 'workHour',
            sourceId: widget.customer.workHours.isNotEmpty
                ? widget.customer.workHours[0].id
                : null,
          ),
          // KM maliyetini ayrı kalem olarak ekleyelim (eğer işçilik kayıtlarında KM varsa)
          if (widget.customer.workHours.isNotEmpty &&
              widget.customer.workHours[0].totalKilometerCost > 0)
            InvoiceItem(
              id: uuid.v4(),
              description: 'Genel Montaj Hizmeti KM Maliyeti',
              quantity: 1.0,
              unitPrice: widget.customer.workHours[0].totalKilometerCost,
              type: 'kilometerCost',
              sourceId: '${widget.customer.workHours[0].id}_km',
            ),
        ],
        status: 'overdue',
        paymentTerms: '14 Gün Net',
        notes: 'Ödeme gecikmiş. Hatırlatma gönderildi.',
      ),
      Invoice(
        id: uuid.v4(),
        customer: widget.customer,
        invoiceNumber:
            'INV-${DateFormat('yyyyMMdd').format(DateTime.now())}-002',
        invoiceDate: DateTime.now().subtract(const Duration(days: 5)),
        dueDate: DateTime.now().add(const Duration(days: 9)),
        items: [
          InvoiceItem(
            id: uuid.v4(),
            description: 'Duvar Boyama',
            quantity: 5.0,
            unitPrice: 25.0,
            type: 'material',
            sourceId: null,
          ),
          InvoiceItem(
            id: uuid.v4(),
            description: 'Danışmanlık Saati',
            quantity: 1.5,
            unitPrice: 75.0,
            type: 'workHour',
            sourceId: null,
          ),
        ],
        status: 'pending',
        paymentTerms: '14 Gün Net',
        notes: 'Müşteri onayı bekleniyor.',
      ),
    ];
    _onSearchChanged();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        filteredInvoices = List.from(invoices);
      } else {
        filteredInvoices = invoices
            .where(
              (invoice) =>
                  invoice.invoiceNumber.toLowerCase().contains(query) ||
                  invoice.customer.name.toLowerCase().contains(query) ||
                  invoice.items.any(
                    (item) => item.description.toLowerCase().contains(query),
                  ) ||
                  invoice.status.toLowerCase().contains(query),
            )
            .toList();
      }
    });
  }

  void _addInvoice() async {
    final Invoice? newInvoice = await showDialog(
      context: context,
      builder: (context) => InvoiceForm(customer: widget.customer),
    );
    if (newInvoice != null) {
      setState(() {
        invoices.add(newInvoice);
        _onSearchChanged();
      });
    }
  }

  void _editInvoice(Invoice invoice) async {
    final Invoice? updatedInvoice = await showDialog(
      context: context,
      builder: (context) =>
          InvoiceForm(customer: widget.customer, initialInvoice: invoice),
    );
    if (updatedInvoice != null) {
      setState(() {
        final idx = invoices.indexWhere((inv) => inv.id == invoice.id);
        if (idx != -1) {
          invoices[idx] = updatedInvoice;
        } else {
          invoices.add(updatedInvoice); // Çok nadir, ama olabilir
        }
        _onSearchChanged();
      });
    }
  }

  void _removeInvoice(Invoice invoice) {
    setState(() {
      invoices.removeWhere((inv) => inv.id == invoice.id);
      _onSearchChanged();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Fatura silindi: ${invoice.invoiceNumber}"),
        backgroundColor: AppColors.error,
        action: SnackBarAction(
          label: "Geri Al",
          textColor: AppColors.white,
          onPressed: () {
            setState(() {
              invoices.add(invoice);
              _onSearchChanged();
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: AppColors.white),
              decoration: InputDecoration(
                hintText: "Fatura numarası veya durum ara",
                hintStyle: const TextStyle(color: AppColors.textSecondary),
                prefixIcon: const Icon(
                  Icons.search,
                  color: AppColors.yellowAccent,
                ),
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.yellowAccent),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.yellowAccent),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                    color: AppColors.yellowAccent,
                    width: 2,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: filteredInvoices.isEmpty
                ? const Center(
                    child: Text(
                      "Kayıtlı fatura yok.",
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 18,
                      ),
                    ),
                  )
                : ListView.separated(
                    itemCount: filteredInvoices.length,
                    separatorBuilder: (_, __) =>
                        Divider(color: AppColors.divider),
                    itemBuilder: (context, i) {
                      final invoice = filteredInvoices[i];
                      Color statusColor = AppColors.textSecondary;
                      if (invoice.status == 'paid') {
                        statusColor = Colors.green;
                      } else if (invoice.status == 'overdue') {
                        statusColor = AppColors.error;
                      }

                      return Dismissible(
                        key: Key(invoice.id),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: AppColors.error,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: const Icon(
                            Icons.delete,
                            color: AppColors.white,
                            size: 32,
                          ),
                        ),
                        onDismissed: (_) => _removeInvoice(invoice),
                        child: Card(
                          color: AppColors.surface,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          child: ListTile(
                            title: Text(
                              'Fatura No: ${invoice.invoiceNumber}',
                              style: AppTextStyles.subtitle.copyWith(
                                color: AppColors.white,
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Müşteri: ${invoice.customer.name}',
                                  style: AppTextStyles.body.copyWith(
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                Text(
                                  'Tarih: ${DateFormat('dd.MM.yyyy').format(invoice.invoiceDate)}',
                                  style: AppTextStyles.body.copyWith(
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                Text(
                                  'Son Ödeme: ${DateFormat('dd.MM.yyyy').format(invoice.dueDate)}',
                                  style: AppTextStyles.body.copyWith(
                                    color: AppColors.textSecondary,
                                  ),
                                ),
                                Text(
                                  'Durum: ${invoice.status == 'pending' ? 'Beklemede' : (invoice.status == 'paid' ? 'Ödendi' : 'Gecikmiş')}',
                                  style: AppTextStyles.body.copyWith(
                                    color: statusColor,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Toplam: ${invoice.totalAmount.toStringAsFixed(2)} €',
                                  style: AppTextStyles.subtitle.copyWith(
                                    color: AppColors.yellowAccent,
                                  ),
                                ),
                                if (invoice.items.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Text(
                                      'Kalemler:',
                                      style: AppTextStyles.caption.copyWith(
                                        color: AppColors.textSecondary,
                                      ),
                                    ),
                                  ),
                                ...invoice.items
                                    .map(
                                      (item) => Padding(
                                        padding: const EdgeInsets.only(
                                          left: 8.0,
                                        ),
                                        child: Text(
                                          '- ${item.description} (${item.quantity} x ${item.unitPrice.toStringAsFixed(2)} €)',
                                          style: AppTextStyles.caption.copyWith(
                                            color: AppColors.textSecondary
                                                .withOpacity(0.8),
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList(),
                              ],
                            ),
                            trailing: const Icon(
                              Icons.visibility,
                              color: AppColors.yellowAccent,
                            ),
                            onTap: () => _editInvoice(invoice),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.yellowAccent,
        foregroundColor: AppColors.background,
        onPressed: _addInvoice,
        tooltip: "Yeni Fatura Oluştur",
        child: const Icon(Icons.add),
      ),
    );
  }
}
