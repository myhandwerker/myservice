// lib/modules/invoices/invoice_item_model.dart

import 'package:uuid/uuid.dart'; // Benzersiz ID'ler için uuid paketi eklenecek

class InvoiceItem {
  final String id; // Kalemin benzersiz ID'si
  final String
  description; // Kalemin açıklaması (örn: Laminat Verlegung, Laminat)
  final double quantity; // Miktar (örn: 3, 16.50)
  final String unit; // Birim (örn: Std., m², Adet, Psch.)
  final double unitPrice; // Birim fiyat (örn: 96.00, 16.50)
  final double total; // Toplam Fiyat (quantity * unitPrice)

  // Varsayılan bir Uuid nesnesi oluştur
  static const Uuid _uuid = Uuid();

  InvoiceItem({
    String? id, // Eğer null gelirse yeni bir UUID oluşturulacak
    required this.description,
    required this.quantity,
    required this.unit,
    required this.unitPrice,
  }) : id = id ?? _uuid.v4(), // ID verilmezse otomatik UUID atar
       total = quantity * unitPrice; // total otomatik hesaplanır

  InvoiceItem copyWith({
    String? id,
    String? description,
    double? quantity,
    String? unit,
    double? unitPrice,
  }) {
    return InvoiceItem(
      id: id ?? this.id,
      description: description ?? this.description,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      unitPrice: unitPrice ?? this.unitPrice,
      // total, quantity ve unitPrice değiştiğinde otomatik olarak yeniden hesaplanır
    );
  }
}
