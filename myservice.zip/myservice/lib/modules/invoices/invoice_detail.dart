// lib/modules/invoices/invoice_detail.dart

import 'package:flutter/material.dart';
import 'invoice_model.dart'; // Fatura modelimiz
import '../customers/customer_model.dart'; // Müşteri modelimiz
import '../../utils/constants.dart'; // Uygulama sabitlerimiz (renkler, stiller)

// Bu kısım normalde merkezi bir yerden gelmeli (State Management)
// Şimdilik InvoiceList'teki gibi örnek bir müşteri listesi kullanıyoruz.
// Customer modelindeki zorunlu alanlar buraya da eklendi.
final List<Customer> customers = [
  Customer(
    id: "1",
    name: "Ali Veli",
    address: "Örnek Adres 1",
    phone: "5551112233",
    email: "ali.veli@example.com",
  ),
  Customer(
    id: "2",
    name: "Ayşe Yılmaz",
    address: "Örnek Adres 2",
    phone: "5554445566",
    email: "ayse.yilmaz@example.com",
  ),
  Customer(
    id: "3",
    name: "Mehmet Can",
    address: "Örnek Adres 3",
    phone: "5557778899",
    email: "mehmet.can@example.com",
  ),
];

class InvoiceDetail extends StatelessWidget {
  final Invoice invoice; // Gösterilecek fatura nesnesi

  const InvoiceDetail({super.key, required this.invoice});

  // Müşteri ID'sine göre müşteri adını getiren yardımcı fonksiyon
  String _getCustomerName(String? customerId) {
    if (customerId == null) return "Bilinmiyor";
    // Customer nesnesini oluştururken zorunlu alanlar eklendi
    final customer = customers.firstWhere(
      (c) => c.id == customerId,
      orElse: () => Customer(
        id: '',
        name: 'Bilinmiyor',
        address: '',
        phone: '',
        email: '',
      ), // Zorunlu alanlar eklendi
    );
    return customer.name;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(invoice.title),
        actions: [
          // Fatura düzenleme butonu eklenebilir
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Faturayı düzenleme özelliği gelecek!"),
                ),
              );
              // TODO: Faturayı düzenlemek için InvoiceForm'u aç
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(builder: (_) => InvoiceForm(initialInvoice: invoice)),
              // ).then((updatedInvoice) {
              //   if (updatedInvoice != null) {
              //     // Fatura listesini güncellemek için bir callback veya state management kullanılabilir.
              //     // Şimdilik bir mesaj göstereceğiz.
              //     ScaffoldMessenger.of(context).showSnackBar(
              //       SnackBar(content: Text("${updatedInvoice.title} güncellendi!")),
              //     );
              //   }
              // });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          // Daha fazla detay eklendiğinde kaydırılabilir olması için ListView kullandık
          children: [
            // Fatura Başlığı (AppBar'da zaten var, isteğe bağlı)
            // Text(
            //   invoice.title,
            //   style: AppTextStyles.title.copyWith(color: AppColors.yellowAccent),
            // ),
            // const SizedBox(height: 16),
            _buildDetailRow(
              context,
              "Müşteri:",
              _getCustomerName(invoice.customerId),
            ),
            _buildDetailRow(
              context,
              "Tutar:",
              "${invoice.amount.toStringAsFixed(2)} ₺",
            ),
            _buildDetailRow(
              context,
              "Fatura Tarihi:",
              "${invoice.issueDate.day}.${invoice.issueDate.month}.${invoice.issueDate.year}",
            ),
            _buildDetailRow(
              context,
              "Son Ödeme Tarihi:",
              "${invoice.dueDate.day}.${invoice.dueDate.month}.${invoice.dueDate.year}",
            ),
            _buildStatusRow(context, invoice.status),

            if (invoice.description != null &&
                invoice.description!.isNotEmpty) ...[
              const SizedBox(height: 24),
              Text(
                "Açıklama:",
                style: AppTextStyles.subtitle.copyWith(
                  color: AppColors.yellowAccent,
                ),
              ),
              const SizedBox(height: 8),
              Text(invoice.description!, style: AppTextStyles.body),
            ],

            // İleride fatura kalemleri, ödeme geçmişi gibi ek bilgiler buraya eklenebilir
            const SizedBox(height: 32),
            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  // TODO: Faturayı PDF olarak indirme veya paylaşma özelliği
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Faturayı dışa aktarma özelliği gelecek!"),
                    ),
                  );
                },
                icon: const Icon(Icons.download),
                label: const Text("Faturayı İndir / Paylaş"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.yellowAccent,
                  foregroundColor: AppColors.background,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                  textStyle: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Ortak detay satırları için yardımcı widget
  Widget _buildDetailRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150, // Etiket genişliği için sabit bir değer
            child: Text(
              label,
              style: AppTextStyles.body.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.yellowAccent,
              ),
            ),
          ),
          Expanded(child: Text(value, style: AppTextStyles.body)),
        ],
      ),
    );
  }

  // Durum bilgisini özel olarak gösteren yardımcı widget
  Widget _buildStatusRow(BuildContext context, InvoiceStatus status) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              "Durum:",
              style: AppTextStyles.body.copyWith(
                fontWeight: FontWeight.bold,
                color: AppColors.yellowAccent,
              ),
            ),
          ),
          Icon(Icons.circle, size: 14, color: status.displayColor),
          const SizedBox(width: 8),
          Text(
            status.displayName,
            style: AppTextStyles.body.copyWith(color: status.displayColor),
          ),
        ],
      ),
    );
  }
}
