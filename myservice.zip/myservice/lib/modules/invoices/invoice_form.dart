// lib/modules/invoices/invoice_form.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../utils/constants.dart';
import '../customers/customer_model.dart'; // Müşteri modelini import et
import 'invoice_model.dart'; // Fatura modelini import et

class InvoiceForm extends StatefulWidget {
  final Invoice? initialInvoice; // Düzenlenecek fatura (opsiyonel)
  final Customer customer; // Faturanın ait olduğu müşteri

  const InvoiceForm({super.key, this.initialInvoice, required this.customer});

  @override
  State<InvoiceForm> createState() => _InvoiceFormState();
}

class _InvoiceFormState extends State<InvoiceForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _invoiceNumberController;
  late TextEditingController _discountController;
  late TextEditingController _notesController;
  late DateTime _issueDate;
  late DateTime _dueDate;
  late InvoiceStatus _selectedStatus;

  List<InvoiceItem> _items = [];

  // Item Form Controllers
  final _itemDescriptionController = TextEditingController();
  final _itemQuantityController = TextEditingController();
  final _itemUnitController = TextEditingController();
  final _itemUnitPriceController = TextEditingController();
  InvoiceItem? _currentItemEdit; // Düzenlenen fatura kalemi

  @override
  void initState() {
    super.initState();
    _invoiceNumberController =
        TextEditingController(text: widget.initialInvoice?.invoiceNumber ?? '');
    _discountController = TextEditingController(
        text: widget.initialInvoice?.discount?.toStringAsFixed(0) ?? '');
    _notesController =
        TextEditingController(text: widget.initialInvoice?.notes ?? '');
    _issueDate = widget.initialInvoice?.issueDate ?? DateTime.now();
    _dueDate = widget.initialInvoice?.dueDate ??
        DateTime.now().add(const Duration(days: 30));
    _selectedStatus = widget.initialInvoice?.status ?? InvoiceStatus.draft;

    if (widget.initialInvoice != null) {
      _items = List.from(widget.initialInvoice!.items);
    }
  }

  @override
  void dispose() {
    _invoiceNumberController.dispose();
    _discountController.dispose();
    _notesController.dispose();
    _itemDescriptionController.dispose();
    _itemQuantityController.dispose();
    _itemUnitController.dispose();
    _itemUnitPriceController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context, bool isIssueDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isIssueDate ? _issueDate : _dueDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: ThemeData.dark().copyWith(
            colorScheme: ColorScheme.dark(
              primary: AppColors.yellowAccent,
              onPrimary: AppColors.primary,
              onSurface: AppColors.white,
              surface: AppColors.surface,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: AppColors.yellowAccent,
              ),
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        if (isIssueDate) {
          _issueDate = picked;
        } else {
          _dueDate = picked;
        }
      });
    }
  }

  void _addOrUpdateItem() {
    if (_itemDescriptionController.text.isEmpty ||
        _itemQuantityController.text.isEmpty ||
        _itemUnitController.text.isEmpty ||
        _itemUnitPriceController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Lütfen tüm fatura kalemi alanlarını doldurun!'),
          backgroundColor: AppColors.error,
        ),
      );
      return;
    }

    final newItem = InvoiceItem(
      id: _currentItemEdit?.id ?? const Uuid().v4(),
      description: _itemDescriptionController.text,
      quantity: double.tryParse(_itemQuantityController.text) ?? 0.0,
      unit: _itemUnitController.text,
      unitPrice: double.tryParse(_itemUnitPriceController.text) ?? 0.0,
    );

    setState(() {
      if (_currentItemEdit != null) {
        final index =
            _items.indexWhere((item) => item.id == _currentItemEdit!.id);
        if (index != -1) {
          _items[index] = newItem;
        }
      } else {
        _items.add(newItem);
      }
      _clearItemForm();
    });
  }

  void _deleteItem(String id) {
    setState(() {
      _items.removeWhere((item) => item.id == id);
    });
  }

  void _clearItemForm() {
    _itemDescriptionController.clear();
    _itemQuantityController.clear();
    _itemUnitController.clear();
    _itemUnitPriceController.clear();
    _currentItemEdit = null;
  }

  void _saveInvoice() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final newInvoice = Invoice(
        id: widget.initialInvoice?.id ?? const Uuid().v4(),
        invoiceNumber: _invoiceNumberController.text,
        customer: widget.customer, // Mevcut müşteri kullanılıyor
        issueDate: _issueDate,
        dueDate: _dueDate,
        status: _selectedStatus,
        items: _items,
        discount: double.tryParse(_discountController.text),
        notes: _notesController.text.isEmpty ? null : _notesController.text,
      );

      Navigator.of(context).pop(newInvoice);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Toplam tutarları hesapla
    final subtotal = _items.fold(0.0, (sum, item) => sum + item.total);
    final discountAmount =
        (subtotal * (double.tryParse(_discountController.text) ?? 0.0) / 100);
    final totalAmount = subtotal - discountAmount;

    return Dialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.borderRadius)),
      backgroundColor: AppColors.background,
      child: SizedBox(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.9,
        child: Column(
          children: [
            AppBar(
              backgroundColor: AppColors.surface,
              title: Text(
                widget.initialInvoice == null
                    ? 'Yeni Fatura Oluştur'
                    : 'Faturayı Düzenle',
                style: AppTextStyles.headlineSmall
                    .copyWith(color: AppColors.yellowAccent),
              ),
              leading: IconButton(
                icon: const Icon(Icons.close, color: AppColors.yellowAccent),
                onPressed: () => Navigator.of(context).pop(),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.save, color: AppColors.yellowAccent),
                  onPressed: _saveInvoice,
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(AppConstants.padding),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Müşteri: ${widget.customer.name}',
                        style: AppTextStyles.titleLarge
                            .copyWith(color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: AppConstants.padding),
                      TextFormField(
                        controller: _invoiceNumberController,
                        decoration: InputDecoration(
                          labelText: 'Fatura Numarası*',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                        ),
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Fatura numarası boş bırakılamaz';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: AppConstants.padding),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _selectDate(context, true),
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.surface),
                              child: Text(
                                'Fatura Tarihi: ${DateFormat('dd.MM.yyyy').format(_issueDate)}',
                                style: AppTextStyles.button
                                    .copyWith(color: AppColors.yellowAccent),
                              ),
                            ),
                          ),
                          const SizedBox(width: AppConstants.padding),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => _selectDate(context, false),
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.surface),
                              child: Text(
                                'Son Ödeme: ${DateFormat('dd.MM.yyyy').format(_dueDate)}',
                                style: AppTextStyles.button
                                    .copyWith(color: AppColors.yellowAccent),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppConstants.padding),
                      DropdownButtonFormField<InvoiceStatus>(
                        value: _selectedStatus,
                        dropdownColor: AppColors.surface,
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                        decoration: InputDecoration(
                          labelText: 'Durum',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide:
                                BorderSide(color: AppColors.textSecondary),
                          ),
                          focusedBorder: const UnderlineInputBorder(
                            borderSide:
                                BorderSide(color: AppColors.yellowAccent),
                          ),
                        ),
                        items: InvoiceStatus.values.map((status) {
                          return DropdownMenuItem(
                            value: status,
                            child: Text(
                              status.toString().split('.').last.toUpperCase(),
                              style: AppTextStyles.body
                                  .copyWith(color: AppColors.white),
                            ),
                          );
                        }).toList(),
                        onChanged: (status) {
                          if (status != null) {
                            setState(() {
                              _selectedStatus = status;
                            });
                          }
                        },
                      ),
                      const Divider(
                          color: AppColors.divider,
                          height: AppConstants.padding * 2),

                      // MARK: - Fatura Kalemleri Yönetimi
                      Text(
                        _currentItemEdit == null
                            ? 'Yeni Fatura Kalemi Ekle'
                            : 'Fatura Kalemini Düzenle',
                        style: AppTextStyles.titleMedium
                            .copyWith(color: AppColors.yellowAccent),
                      ),
                      const SizedBox(height: AppConstants.padding),
                      TextFormField(
                        controller: _itemDescriptionController,
                        decoration: InputDecoration(
                          labelText: 'Açıklama',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                        ),
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                      ),
                      const SizedBox(height: AppConstants.padding),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _itemQuantityController,
                              decoration: InputDecoration(
                                labelText: 'Miktar',
                                labelStyle: AppTextStyles.body
                                    .copyWith(color: AppColors.textSecondary),
                              ),
                              style: AppTextStyles.body
                                  .copyWith(color: AppColors.white),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          const SizedBox(width: AppConstants.padding),
                          Expanded(
                            child: TextFormField(
                              controller: _itemUnitController,
                              decoration: InputDecoration(
                                labelText: 'Birim',
                                labelStyle: AppTextStyles.body
                                    .copyWith(color: AppColors.textSecondary),
                              ),
                              style: AppTextStyles.body
                                  .copyWith(color: AppColors.white),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppConstants.padding),
                      TextFormField(
                        controller: _itemUnitPriceController,
                        decoration: InputDecoration(
                          labelText: 'Birim Fiyatı (TL)',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                        ),
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                        keyboardType: TextInputType.number,
                      ),
                      const SizedBox(height: AppConstants.padding),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          if (_currentItemEdit != null)
                            TextButton(
                              onPressed: _clearItemForm,
                              child: Text('İptal',
                                  style: AppTextStyles.button.copyWith(
                                      color: AppColors.textSecondary)),
                            ),
                          ElevatedButton(
                            onPressed: _addOrUpdateItem,
                            style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.accent),
                            child: Text(
                              _currentItemEdit == null ? 'Ekle' : 'Güncelle',
                              style: AppTextStyles.button
                                  .copyWith(color: AppColors.white),
                            ),
                          ),
                        ],
                      ),
                      const Divider(
                          color: AppColors.divider,
                          height: AppConstants.padding * 2),
                      Text(
                        'Fatura Kalemleri Listesi',
                        style: AppTextStyles.titleMedium
                            .copyWith(color: AppColors.yellowAccent),
                      ),
                      const SizedBox(height: AppConstants.padding),
                      _items.isEmpty
                          ? Center(
                              child: Text(
                                'Henüz fatura kalemi eklenmedi.',
                                style: AppTextStyles.bodyMedium
                                    .copyWith(color: AppColors.textSecondary),
                              ),
                            )
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: _items.length,
                              itemBuilder: (context, index) {
                                final item = _items[index];
                                return Card(
                                  color: AppColors.surface,
                                  margin: const EdgeInsets.only(
                                      bottom: AppConstants.padding / 2),
                                  child: ListTile(
                                    title: Text(item.description,
                                        style: AppTextStyles.titleSmall),
                                    subtitle: Text(
                                      '${item.quantity} ${item.unit} x ${item.unitPrice} TL',
                                      style: AppTextStyles.bodySmall.copyWith(
                                          color: AppColors.textSecondary),
                                    ),
                                    trailing: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          '${item.total.toStringAsFixed(2)} TL',
                                          style: AppTextStyles.titleSmall
                                              .copyWith(
                                                  color:
                                                      AppColors.yellowAccent),
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.edit,
                                              color: AppColors.info),
                                          onPressed: () {
                                            setState(() {
                                              _currentItemEdit = item;
                                              _itemDescriptionController.text =
                                                  item.description;
                                              _itemQuantityController.text =
                                                  item.quantity.toString();
                                              _itemUnitController.text =
                                                  item.unit;
                                              _itemUnitPriceController.text =
                                                  item.unitPrice.toString();
                                            });
                                          },
                                        ),
                                        IconButton(
                                          icon: const Icon(Icons.delete,
                                              color: AppColors.error),
                                          onPressed: () => _deleteItem(item.id),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                      const Divider(
                          color: AppColors.divider,
                          height: AppConstants.padding * 2),

                      // MARK: - Fatura Özeti
                      Text(
                        'Fatura Özeti',
                        style: AppTextStyles.titleMedium
                            .copyWith(color: AppColors.yellowAccent),
                      ),
                      const SizedBox(height: AppConstants.padding),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Ara Toplam:', style: AppTextStyles.bodyLarge),
                          Text('${subtotal.toStringAsFixed(2)} TL',
                              style: AppTextStyles.bodyLarge),
                        ],
                      ),
                      const SizedBox(height: AppConstants.padding / 2),
                      TextFormField(
                        controller: _discountController,
                        decoration: InputDecoration(
                          labelText: 'İndirim Oranı (%)',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                        ),
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                        keyboardType: TextInputType.number,
                        onChanged: (value) {
                          setState(() {}); // Anlık indirim hesaplaması için
                        },
                      ),
                      const SizedBox(height: AppConstants.padding / 2),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('İndirim Tutarı:',
                              style: AppTextStyles.bodyLarge
                                  .copyWith(color: AppColors.warning)),
                          Text('- ${discountAmount.toStringAsFixed(2)} TL',
                              style: AppTextStyles.bodyLarge
                                  .copyWith(color: AppColors.warning)),
                        ],
                      ),
                      const SizedBox(height: AppConstants.padding / 2),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Toplam Tutar:',
                              style: AppTextStyles.headlineSmall
                                  .copyWith(color: AppColors.yellowAccent)),
                          Text('${totalAmount.toStringAsFixed(2)} TL',
                              style: AppTextStyles.headlineSmall
                                  .copyWith(color: AppColors.yellowAccent)),
                        ],
                      ),
                      const SizedBox(height: AppConstants.padding),
                      TextFormField(
                        controller: _notesController,
                        decoration: InputDecoration(
                          labelText: 'Notlar (Opsiyonel)',
                          labelStyle: AppTextStyles.body
                              .copyWith(color: AppColors.textSecondary),
                        ),
                        style:
                            AppTextStyles.body.copyWith(color: AppColors.white),
                        maxLines: 3,
                      ),
                      const SizedBox(height: AppConstants.padding),
                      Center(
                        child: ElevatedButton(
                          onPressed: _saveInvoice,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.yellowAccent,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 40, vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  AppConstants.borderRadius),
                            ),
                          ),
                          child: Text(
                            widget.initialInvoice == null
                                ? 'Fatura Oluştur'
                                : 'Fatura Güncelle',
                            style: AppTextStyles.button
                                .copyWith(color: AppColors.primary),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
