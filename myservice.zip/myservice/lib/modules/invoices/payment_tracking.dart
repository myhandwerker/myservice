/// Ödeme takibini yapmak için kullanılan sayfa.

import 'package:flutter/material.dart';

class PaymentTracking extends StatelessWidget {
  const PaymentTracking({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ödeme Takibi')),
      body: const Center(child: Text('Burada ödeme takibi yapılacak')),
    );
  }
}
