import 'package:flutter/material.dart';
import 'task_model.dart';
import 'task_form.dart';
import 'calendar.dart';
import '../customers/customer_model.dart'; // customer_model.dart importu doğru

// Örnek müşteri listesi, zorunlu alanlar eklendi
final List<Customer> customers = [
  Customer(
    id: "1",
    name: "Ali Veli",
    address: "Örnek Adres 1",
    phone: "5551112233",
    email: "ali.veli@example.com",
  ),
  Customer(
    id: "2",
    name: "Ayşe Yılmaz",
    address: "Örnek Adres 2",
    phone: "5554445566",
    email: "ayse.yilmaz@example.com",
  ),
];

class TaskList extends StatefulWidget {
  const TaskList({super.key});

  @override
  State<TaskList> createState() => _TaskListState();
}

class _TaskListState extends State<TaskList>
    with SingleTickerProviderStateMixin {
  List<Task> tasks = [];
  TaskStatus? filter;
  String? selectedCustomerId;
  String search = "";
  int tasksPerPage = 20;
  int currentMaxIndex = 20;
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _scrollController.addListener(_onScroll);

    // Başlangıçta birkaç örnek görev ekleyelim
    tasks.add(
      Task(
        id: 'T001',
        title: 'Müşteri Toplantısı',
        description: 'Yeni proje için Ali Veli ile toplantı.',
        date: DateTime(2025, 6, 10),
        status: TaskStatus.todo,
        customerId: '1',
      ),
    );
    tasks.add(
      Task(
        id: 'T002',
        title: 'Mobil Uygulama Güncellemesi',
        description: 'Ayşe Yılmaz\'ın uygulamasında hata düzeltmeleri.',
        date: DateTime(2025, 6, 12),
        status: TaskStatus.inProgress,
        customerId: '2',
      ),
    );
    tasks.add(
      Task(
        id: 'T003',
        title: 'Faturalandırma Kontrolü',
        description: 'Mayıs ayı faturalarının kontrolü ve gönderimi.',
        date: DateTime(2025, 6, 8),
        status: TaskStatus.done,
        customerId: '1', // Örnek olarak Ali Veli'ye atanabilir
      ),
    );
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      if (currentMaxIndex < filteredTasks.length) {
        setState(() {
          currentMaxIndex = (currentMaxIndex + tasksPerPage).clamp(
            0,
            filteredTasks.length,
          );
        });
      }
    }
  }

  void _addTask(Task task) {
    setState(() {
      final idx = tasks.indexWhere((t) => t.id == task.id);
      if (idx != -1) {
        tasks[idx] = task; // Güncelleme
      } else {
        tasks.add(task); // Yeni ekleme
      }
    });
  }

  void _editTask(Task task) async {
    final editedTask = await Navigator.push<Task>(
      context,
      MaterialPageRoute(builder: (_) => TaskForm(initialTask: task)),
    );
    if (editedTask != null) _addTask(editedTask);
  }

  void _deleteTask(Task task) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Görev Sil"),
        content: Text("Bu görevi silmek istediğine emin misin?"),
        actions: [
          TextButton(
            child: const Text("İptal"),
            onPressed: () => Navigator.pop(ctx),
          ),
          TextButton(
            child: const Text("Sil"),
            onPressed: () {
              setState(() {
                tasks.removeWhere((t) => t.id == task.id);
              });
              Navigator.pop(ctx);
            },
          ),
        ],
      ),
    );
  }

  List<Task> get filteredTasks {
    var result = tasks;
    if (filter != null) {
      result = result.where((t) => t.status == filter).toList();
    }
    if (selectedCustomerId != null) {
      result = result.where((t) => t.customerId == selectedCustomerId).toList();
    }
    if (search.isNotEmpty) {
      result = result
          .where(
            (t) =>
                t.title.toLowerCase().contains(search.toLowerCase()) ||
                t.description.toLowerCase().contains(search.toLowerCase()),
          )
          .toList();
    }
    result.sort((a, b) => b.date.compareTo(a.date));
    return result;
  }

  Map<String, List<Task>> get groupedTasks {
    final map = <String, List<Task>>{};
    for (var task in filteredTasks.take(currentMaxIndex)) {
      final key = "${task.date.day}.${task.date.month}.${task.date.year}";
      map.putIfAbsent(key, () => []).add(task);
    }
    return map;
  }

  String getCustomerName(String? customerId) {
    if (customerId == null) return "Bilinmiyor";
    // Customer nesnesini oluştururken zorunlu alanlar eklendi
    final customer = customers.firstWhere(
      (c) => c.id == customerId,
      orElse: () => Customer(
        id: '',
        name: 'Bilinmiyor',
        address: '',
        phone: '',
        email: '',
      ), // Zorunlu alanlar eklendi
    );
    return customer.name;
  }

  bool isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year &&
        date.month == now.month &&
        date.day == now.day;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Görevler"),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.list), text: "Liste"),
            Tab(icon: Icon(Icons.calendar_today), text: "Takvim"),
          ],
        ),
        actions: _tabController.index == 0
            ? [
                DropdownButton<String?>(
                  value: selectedCustomerId,
                  hint: const Text("Müşteri"),
                  items: [
                    const DropdownMenuItem(value: null, child: Text("Tümü")),
                    ...customers.map(
                      (c) => DropdownMenuItem(value: c.id, child: Text(c.name)),
                    ),
                  ],
                  onChanged: (val) => setState(() {
                    selectedCustomerId = val;
                    currentMaxIndex = tasksPerPage;
                  }),
                ),
                DropdownButton<TaskStatus?>(
                  value: filter,
                  hint: const Text("Durum"),
                  items: const [
                    DropdownMenuItem(value: null, child: Text("Tümü")),
                    DropdownMenuItem(
                      value: TaskStatus.todo,
                      child: Text("Beklemede"),
                    ),
                    DropdownMenuItem(
                      value: TaskStatus.inProgress,
                      child: Text("Devam Ediyor"),
                    ),
                    DropdownMenuItem(
                      value: TaskStatus.done,
                      child: Text("Yapıldı"),
                    ),
                  ],
                  onChanged: (val) => setState(() {
                    filter = val;
                    currentMaxIndex = tasksPerPage;
                  }),
                ),
              ]
            : null,
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Liste görünümü
          Column(
            children: [
              // Arama kutusu
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: "Görev Ara",
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (v) {
                    setState(() {
                      search = v;
                      currentMaxIndex = tasksPerPage;
                    });
                  },
                ),
              ),
              Expanded(
                child: groupedTasks.isEmpty
                    ? const Center(child: Text("Görev yok"))
                    : ListView(
                        controller: _scrollController,
                        children: [
                          for (var entry in groupedTasks.entries)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  color: Colors.grey[200],
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 6,
                                    horizontal: 12,
                                  ),
                                  child: Text(
                                    entry.key,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                ),
                                ...entry.value.map(
                                  (task) => ListTile(
                                    tileColor: isToday(task.date)
                                        ? Colors.yellow[100]
                                        : null,
                                    leading: Stack(
                                      children: [
                                        Icon(
                                          task.status == TaskStatus.done
                                              ? Icons.check_circle
                                              : task.status ==
                                                    TaskStatus.inProgress
                                              ? Icons.timelapse
                                              : Icons.radio_button_unchecked,
                                          color: task.status == TaskStatus.done
                                              ? Colors.green
                                              : task.status ==
                                                    TaskStatus.inProgress
                                              ? Colors.orange
                                              : Colors.grey,
                                        ),
                                        if (isToday(task.date))
                                          const Positioned(
                                            right: 0,
                                            bottom: 0,
                                            child: Icon(
                                              Icons.notifications_active,
                                              color: Colors.redAccent,
                                              size: 18,
                                            ),
                                          ),
                                      ],
                                    ),
                                    title: Text(task.title),
                                    subtitle: Text(
                                      "${task.description}\nMüşteri: ${getCustomerName(task.customerId)}\nDurum: ${_statusText(task.status)}",
                                    ),
                                    isThreeLine: true,
                                    trailing: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        IconButton(
                                          icon: const Icon(
                                            Icons.edit,
                                            color: Colors.blue,
                                          ),
                                          onPressed: () => _editTask(task),
                                        ),
                                        IconButton(
                                          icon: const Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                          onPressed: () => _deleteTask(task),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          if (currentMaxIndex < filteredTasks.length)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 16),
                              child: Center(child: CircularProgressIndicator()),
                            ),
                        ],
                      ),
              ),
            ],
          ),
          // Takvim görünümü
          TaskCalendar(tasks: tasks, onTaskAdded: _addTask),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newTask = await Navigator.push<Task>(
            context,
            MaterialPageRoute(builder: (_) => const TaskForm()),
          );
          if (newTask != null) _addTask(newTask);
        },
        child: const Icon(Icons.add),
        tooltip: "Yeni Görev",
      ),
    );
  }

  String _statusText(TaskStatus status) {
    switch (status) {
      case TaskStatus.todo:
        return "Beklemede";
      case TaskStatus.inProgress:
        return "Devam Ediyor";
      case TaskStatus.done:
        return "Yapıldı";
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
