import 'package:flutter/material.dart';
import 'task_model.dart';
import '../customers/customer_model.dart';

// Kendi müşteri listen ile değiştir! (Zorunlu alanlar eklendi)
final List<Customer> customers = [
  Customer(
    id: "1",
    name: "Ali Veli",
    address: "Örnek Adres 1",
    phone: "5551112233",
    email: "ali.veli@example.com",
  ),
  Customer(
    id: "2",
    name: "Ayşe Yılmaz",
    address: "Örnek Adres 2",
    phone: "5554445566",
    email: "ayse.yilmaz@example.com",
  ),
];

class TaskForm extends StatefulWidget {
  final Task? initialTask;
  final String? initialCustomerId;
  final DateTime? initialDate;

  const TaskForm({
    super.key,
    this.initialTask,
    this.initialCustomerId,
    this.initialDate,
  });

  @override
  State<TaskForm> createState() => _TaskFormState();
}

class _TaskFormState extends State<TaskForm> {
  late TextEditingController titleController;
  late TextEditingController descriptionController;
  DateTime? date;
  String? selectedCustomerId;
  TaskStatus? selectedStatus;

  @override
  void initState() {
    super.initState();
    final task = widget.initialTask;
    titleController = TextEditingController(text: task?.title ?? "");
    descriptionController = TextEditingController(
      text: task?.description ?? "",
    );
    date = task?.date ?? widget.initialDate ?? DateTime.now();
    selectedCustomerId = task?.customerId ?? widget.initialCustomerId;
    selectedStatus = task?.status ?? TaskStatus.todo;
  }

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.initialTask != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEditing ? "Görev Düzenle" : "Yeni Görev")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: "Başlık"),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: "Açıklama"),
              minLines: 2,
              maxLines: 4,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: selectedCustomerId,
              decoration: const InputDecoration(labelText: "Müşteri"),
              items: customers
                  .map(
                    // Customer nesnesini oluştururken zorunlu alanlar eklenmeli
                    (c) => DropdownMenuItem(value: c.id, child: Text(c.name)),
                  )
                  .toList(),
              onChanged: (v) => setState(() => selectedCustomerId = v),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<TaskStatus>(
              value: selectedStatus,
              decoration: const InputDecoration(labelText: "Durum"),
              items: const [
                DropdownMenuItem(
                  value: TaskStatus.todo,
                  child: Text("Beklemede"),
                ),
                DropdownMenuItem(
                  value: TaskStatus.inProgress,
                  child: Text("Devam Ediyor"),
                ),
                DropdownMenuItem(
                  value: TaskStatus.done,
                  child: Text("Yapıldı"),
                ),
              ],
              onChanged: (v) => setState(() => selectedStatus = v),
            ),
            const SizedBox(height: 12),
            ListTile(
              title: Text(
                "Tarih: ${date != null ? "${date!.day}.${date!.month}.${date!.year}" : "Seçilmedi"}",
              ),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: date ?? DateTime.now(),
                  firstDate: DateTime.now().subtract(const Duration(days: 365)),
                  lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
                );
                if (picked != null) setState(() => date = picked);
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              child: Text(isEditing ? "Kaydet" : "Ekle"),
              onPressed: () {
                if (titleController.text.trim().isEmpty ||
                    descriptionController.text.trim().isEmpty ||
                    selectedCustomerId == null ||
                    date == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Lütfen tüm alanları doldurun."),
                    ),
                  );
                  return;
                }
                final task = Task(
                  id:
                      widget.initialTask?.id ??
                      DateTime.now().millisecondsSinceEpoch.toString(),
                  title: titleController.text.trim(),
                  description: descriptionController.text.trim(),
                  date: date!,
                  status: selectedStatus!,
                  customerId: selectedCustomerId,
                );
                Navigator.pop(context, task);
              },
            ),
          ],
        ),
      ),
    );
  }
}
