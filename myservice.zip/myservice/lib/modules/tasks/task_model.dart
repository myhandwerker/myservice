enum TaskStatus { todo, inProgress, done }

class Task {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final TaskStatus status;
  final String? customerId;

  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    this.status = TaskStatus.todo,
    this.customerId,
  });

  Task copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    TaskStatus? status,
    String? customerId,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      status: status ?? this.status,
      customerId: customerId ?? this.customerId,
    );
  }
}
