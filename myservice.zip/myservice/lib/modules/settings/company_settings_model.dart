import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class CompanySettings {
  final String companyName;
  final String? companyDescription;
  final String? logoPath;
  final Color? themeColor;
  final Map<String, String> customFields;

  CompanySettings({
    required this.companyName,
    this.companyDescription,
    this.logoPath,
    this.themeColor,
    Map<String, String>? customFields,
  }) : customFields = customFields ?? {};

  CompanySettings copyWith({
    String? companyName,
    String? companyDescription,
    String? logoPath,
    Color? themeColor,
    Map<String, String>? customFields,
  }) {
    return CompanySettings(
      companyName: companyName ?? this.companyName,
      companyDescription: companyDescription ?? this.companyDescription,
      logoPath: logoPath ?? this.logoPath,
      themeColor: themeColor ?? this.themeColor,
      customFields: customFields ?? Map<String, String>.from(this.customFields),
    );
  }

  Map<String, dynamic> toJson() => {
    'companyName': companyName,
    'companyDescription': companyDescription,
    'logoPath': logoPath,
    'themeColor': themeColor?.value,
    'customFields': customFields,
  };

  factory CompanySettings.fromJson(Map<String, dynamic> json) =>
      CompanySettings(
        companyName: json['companyName'] as String,
        companyDescription: json['companyDescription'] as String?,
        logoPath: json['logoPath'] as String?,
        themeColor: json['themeColor'] != null
            ? Color(json['themeColor'] as int)
            : null,
        customFields:
            (json['customFields'] as Map?)?.cast<String, String>() ?? {},
      );

  static const _prefsKey = 'company_settings';

  static Future<void> saveToPrefs(CompanySettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    final data = settings.toJson();
    prefs.setString(_prefsKey, json.encode(data));
  }

  static Future<CompanySettings> loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_prefsKey);
    if (data != null) {
      return CompanySettings.fromJson(json.decode(data));
    } else {
      return CompanySettings(
        companyName: "Demo Şirketi",
        companyDescription: "Açıklamanızı buraya yazabilirsiniz.",
        logoPath: null,
        themeColor: Colors.blue,
      );
    }
  }

  static Future<void> resetToFactoryDefaults() async {
    await saveToPrefs(
      CompanySettings(
        companyName: "Demo Şirketi",
        companyDescription: "Açıklamanızı buraya yazabilirsiniz.",
        logoPath: null,
        themeColor: Colors.blue,
        customFields: {},
      ),
    );
  }
}
