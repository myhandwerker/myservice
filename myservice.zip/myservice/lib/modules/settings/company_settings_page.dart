import 'package:flutter/material.dart';
import 'company_settings_model.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'dart:io';

class CompanySettingsPage extends StatefulWidget {
  final CompanySettings settings;
  final void Function(CompanySettings) onChanged;

  const CompanySettingsPage({
    super.key,
    required this.settings,
    required this.onChanged,
  });

  @override
  State<CompanySettingsPage> createState() => _CompanySettingsPageState();
}

class _CompanySettingsPageState extends State<CompanySettingsPage> {
  final _formKey = GlobalKey<FormState>();
  late CompanySettings _settings;

  final _fieldKeyController = TextEditingController();
  final _fieldValueController = TextEditingController();
  String? _companyNameError;
  String? _logoError;
  String? _companyDescriptionError;

  static const int maxLogoSize = 2 * 1024 * 1024; // 2 MB

  @override
  void initState() {
    _settings = widget.settings;
    super.initState();
  }

  Future<void> _saveSettings(CompanySettings updated) async {
    setState(() {
      _settings = updated;
    });
    widget.onChanged(updated);
    await CompanySettings.saveToPrefs(updated);
  }

  Future<void> _pickLogo() async {
    setState(() {
      _logoError = null;
    });
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      final file = File(picked.path);
      final ext = picked.path.split('.').last.toLowerCase();
      final supported = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
      if (!supported.contains(ext)) {
        setState(() {
          _logoError = 'Yalnızca görsel dosyalar yüklenebilir!';
        });
        return;
      }
      final size = await file.length();
      if (size > maxLogoSize) {
        setState(() {
          _logoError = 'Logo 2 MB\'dan küçük olmalı!';
        });
        return;
      }
      final updated = _settings.copyWith(logoPath: picked.path);
      await _saveSettings(updated);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Logo güncellendi!")));
    }
  }

  void _updateCompanyName(String val) {
    final updated = _settings.copyWith(companyName: val);
    setState(() {
      _companyNameError = (val.trim().isEmpty)
          ? 'Şirket adı boş bırakılamaz'
          : null;
    });
    _saveSettings(updated);
  }

  void _updateCompanyDescription(String? val) {
    final updated = _settings.copyWith(companyDescription: val);
    setState(() {
      _companyDescriptionError = (val == null || val.trim().isEmpty)
          ? 'Şirket açıklaması boş bırakılamaz'
          : null;
    });
    _saveSettings(updated);
  }

  void _updateCustomField(String key, String value) {
    final updatedFields = Map<String, String>.from(_settings.customFields);
    updatedFields[key] = value;
    final updated = _settings.copyWith(customFields: updatedFields);
    _saveSettings(updated);
  }

  void _removeCustomField(String key) {
    final updatedFields = Map<String, String>.from(_settings.customFields);
    updatedFields.remove(key);
    final updated = _settings.copyWith(customFields: updatedFields);
    _saveSettings(updated);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("“$key” özel alanı silindi.")));
  }

  Color _getContrastColor(Color color) {
    final yiq =
        ((color.red * 299) + (color.green * 587) + (color.blue * 114)) / 1000;
    return yiq >= 128 ? Colors.black : Colors.white;
  }

  Future<void> _resetToFactoryDefaults() async {
    await CompanySettings.resetToFactoryDefaults();
    final defaults = await CompanySettings.loadFromPrefs();
    setState(() {
      _settings = defaults;
      _companyNameError = null;
      _companyDescriptionError = null;
      _logoError = null;
    });
    widget.onChanged(defaults);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Ayarlar fabrika ayarlarına döndürüldü!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final logoWidget = Builder(
      builder: (context) {
        if (_settings.logoPath == null) {
          return const Icon(Icons.business, size: 64, color: Colors.grey);
        }
        try {
          final file = File(_settings.logoPath!);
          if (!file.existsSync()) throw Exception();
          return Image.file(
            file,
            width: 64,
            height: 64,
            fit: BoxFit.cover,
            errorBuilder: (context, err, stack) =>
                const Icon(Icons.business, size: 64, color: Colors.grey),
          );
        } catch (_) {
          return const Icon(Icons.business, size: 64, color: Colors.grey);
        }
      },
    );

    final themeColor = _settings.themeColor ?? Colors.blue;
    final contrastColor = _getContrastColor(themeColor);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Şirket Ayarları"),
        backgroundColor: themeColor,
        foregroundColor: contrastColor,
        iconTheme: IconThemeData(color: contrastColor),
        actions: [
          IconButton(
            tooltip: "Fabrika Ayarlarına Dön",
            icon: const Icon(Icons.restore),
            color: contrastColor,
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text("Fabrika Ayarlarına Dön"),
                  content: const Text(
                    "Tüm şirket ayarları varsayılan değere dönecek. Emin misiniz?",
                  ),
                  actions: [
                    TextButton(
                      child: const Text("İptal"),
                      onPressed: () => Navigator.pop(ctx, false),
                    ),
                    TextButton(
                      child: const Text("Evet"),
                      onPressed: () => Navigator.pop(ctx, true),
                    ),
                  ],
                ),
              );
              if (confirm == true) {
                await _resetToFactoryDefaults();
              }
            },
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Firma Adı
            TextFormField(
              initialValue: _settings.companyName,
              decoration: InputDecoration(
                labelText: "Şirket/Firma Adı",
                errorText: _companyNameError,
              ),
              onChanged: _updateCompanyName,
              validator: (val) => (val == null || val.trim().isEmpty)
                  ? 'Şirket adı boş bırakılamaz'
                  : null,
            ),
            const SizedBox(height: 12),
            // Şirket Açıklaması/Slogan
            TextFormField(
              minLines: 1,
              maxLines: 3,
              initialValue: _settings.companyDescription ?? "",
              decoration: InputDecoration(
                labelText: "Şirket Açıklaması / Slogan",
                errorText: _companyDescriptionError,
              ),
              onChanged: _updateCompanyDescription,
              validator: (val) => (val == null || val.trim().isEmpty)
                  ? 'Şirket açıklaması boş bırakılamaz'
                  : null,
            ),
            const SizedBox(height: 20),
            // Logo
            Row(
              children: [
                logoWidget,
                const SizedBox(width: 16),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    foregroundColor: contrastColor,
                  ),
                  onPressed: _pickLogo,
                  icon: const Icon(Icons.upload),
                  label: const Text("Logo Yükle"),
                ),
                if (_settings.logoPath != null)
                  IconButton(
                    icon: const Icon(Icons.clear),
                    tooltip: "Logoyu Kaldır",
                    color: themeColor,
                    onPressed: () async {
                      try {
                        final file = File(_settings.logoPath!);
                        if (await file.exists()) {
                          await file.delete();
                        }
                      } catch (_) {}
                      final updated = _settings.copyWith(logoPath: null);
                      await _saveSettings(updated);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Logo kaldırıldı.")),
                      );
                    },
                  ),
              ],
            ),
            if (_logoError != null)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  _logoError!,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            const SizedBox(height: 20),
            // Tema Rengi
            ListTile(
              title: const Text("Tema Rengi"),
              trailing: CircleAvatar(backgroundColor: themeColor),
              onTap: () async {
                final picked = await showDialog<Color>(
                  context: context,
                  builder: (ctx) => _ColorPickerDialog(initial: themeColor),
                );
                if (picked != null) {
                  final updated = _settings.copyWith(themeColor: picked);
                  await _saveSettings(updated);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Tema rengi güncellendi!")),
                  );
                }
              },
            ),
            const SizedBox(height: 20),
            // Özel Alanlar
            Row(
              children: [
                const Text(
                  "Özel Alanlar",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.add),
                  tooltip: "Yeni Özel Alan",
                  color: themeColor,
                  onPressed: () async {
                    _fieldKeyController.clear();
                    _fieldValueController.clear();
                    String? errorText;
                    await showDialog(
                      context: context,
                      builder: (ctx) => StatefulBuilder(
                        builder: (ctx, setDialogState) => AlertDialog(
                          title: const Text("Özel Alan Ekle"),
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TextField(
                                controller: _fieldKeyController,
                                decoration: InputDecoration(
                                  labelText: "Alan Başlığı",
                                  errorText: errorText,
                                ),
                                onChanged: (v) {
                                  if (_settings.customFields.containsKey(
                                    v.trim(),
                                  )) {
                                    setDialogState(() {
                                      errorText = "Bu başlık zaten var!";
                                    });
                                  } else {
                                    setDialogState(() {
                                      errorText = null;
                                    });
                                  }
                                },
                              ),
                              TextField(
                                controller: _fieldValueController,
                                decoration: const InputDecoration(
                                  labelText: "Değer",
                                ),
                              ),
                            ],
                          ),
                          actions: [
                            TextButton(
                              child: const Text("İptal"),
                              onPressed: () => Navigator.pop(ctx),
                            ),
                            TextButton(
                              child: const Text("Ekle"),
                              onPressed: () {
                                final k = _fieldKeyController.text.trim();
                                final v = _fieldValueController.text.trim();
                                if (k.isEmpty) {
                                  setDialogState(() {
                                    errorText = "Başlık boş olamaz!";
                                  });
                                  return;
                                }
                                if (_settings.customFields.containsKey(k)) {
                                  setDialogState(() {
                                    errorText = "Bu başlık zaten var!";
                                  });
                                  return;
                                }
                                _updateCustomField(k, v);
                                Navigator.pop(ctx);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Özel alan "$k" eklendi!'),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
            ..._settings.customFields.entries.map(
              (e) => ListTile(
                title: Text(e.key),
                subtitle: Text(e.value),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  tooltip: "Sil",
                  color: themeColor,
                  onPressed: () => _removeCustomField(e.key),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Basit bir renk picker dialog
class _ColorPickerDialog extends StatefulWidget {
  final Color initial;
  const _ColorPickerDialog({required this.initial});

  @override
  State<_ColorPickerDialog> createState() => _ColorPickerDialogState();
}

class _ColorPickerDialogState extends State<_ColorPickerDialog> {
  late Color _color;
  @override
  void initState() {
    _color = widget.initial;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Renk Seç"),
      content: SingleChildScrollView(
        child: BlockPicker(
          pickerColor: _color,
          onColorChanged: (c) => setState(() => _color = c),
        ),
      ),
      actions: [
        TextButton(
          child: const Text("İptal"),
          onPressed: () => Navigator.pop(context),
        ),
        TextButton(
          child: const Text("Seç"),
          onPressed: () => Navigator.pop(context, _color),
        ),
      ],
    );
  }
}
