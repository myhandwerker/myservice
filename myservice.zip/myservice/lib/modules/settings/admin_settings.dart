import 'package:flutter/material.dart';

class AdminSettingsPage extends StatefulWidget {
  const AdminSettingsPage({super.key});

  @override
  State<AdminSettingsPage> createState() => _AdminSettingsPageState();
}

class _AdminSettingsPageState extends State<AdminSettingsPage> {
  final _formKey = GlobalKey<FormState>();
  String _adminUsername = "admin";
  String _adminPassword = "";
  String _role = "Yönetici";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Ayarları")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Admin Bilgileri",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              TextFormField(
                initialValue: _adminUsername,
                decoration: const InputDecoration(labelText: "Kullanıcı Adı"),
                validator: (value) => value == null || value.isEmpty
                    ? "Kullanıcı adı giriniz"
                    : null,
                onSaved: (value) => _adminUsername = value ?? _adminUsername,
              ),
              const SizedBox(height: 16),
              TextFormField(
                decoration: const InputDecoration(labelText: "Yeni Parola"),
                obscureText: true,
                onSaved: (value) => _adminPassword = value ?? "",
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _role,
                decoration: const InputDecoration(labelText: "Yetki Seviyesi"),
                items: const [
                  DropdownMenuItem(value: "Yönetici", child: Text("Yönetici")),
                  DropdownMenuItem(
                    value: "Süper Admin",
                    child: Text("Süper Admin"),
                  ),
                  DropdownMenuItem(value: "Okuyucu", child: Text("Okuyucu")),
                ],
                onChanged: (value) =>
                    setState(() => _role = value ?? "Yönetici"),
                onSaved: (value) => _role = value ?? _role,
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  child: const Text("Kaydet"),
                  onPressed: () {
                    if (_formKey.currentState?.validate() ?? false) {
                      _formKey.currentState?.save();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Admin ayarları kaydedildi (örnek)!"),
                        ),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
