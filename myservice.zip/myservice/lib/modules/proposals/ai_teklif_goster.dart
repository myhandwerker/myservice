import 'package:flutter/material.dart';
import 'gemini_service.dart';

class AiTeklifPage extends StatefulWidget {
  @override
  State<AiTeklifPage> createState() => _AiTeklifPageState();
}

class _AiTeklifPageState extends State<AiTeklifPage> {
  final TextEditingController _controller = TextEditingController();
  String _customer = "";
  String _request = "";
  String _description = "";
  bool _loading = false;

  Future<void> _getTeklif() async {
    setState(() => _loading = true);
    try {
      final result = await GeminiService.analyzeMessageAndGenerateProposal(
        message: _controller.text,
      );
      setState(() {
        _customer = result["customer"]!;
        _request = result["request"]!;
        _description = result["description"]!;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("AI başarısız: $e"),
          backgroundColor: Colors.orange,
        ),
      );
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("AI ile Teklif Oluştur")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: 'Müşteri mesajı girin'),
              minLines: 2,
              maxLines: 5,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loading ? null : _getTeklif,
              child: _loading
                  ? CircularProgressIndicator()
                  : Text("AI ile Teklif Alanlarını Doldur"),
            ),
            Divider(),
            if (_customer.isNotEmpty)
              Text(
                "Müşteri: $_customer",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            if (_request.isNotEmpty)
              Text(
                "Talep: $_request",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            if (_description.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text("Açıklama:\n$_description"),
              ),
          ],
        ),
      ),
    );
  }
}
