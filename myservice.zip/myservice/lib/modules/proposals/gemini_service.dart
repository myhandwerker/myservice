import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiService {
  static const String apiKey = 'AIzaSyDfghlEi7LkfBLunB4yVOlC4RC3anQjxgQ';

  static Future<Map<String, String>> analyzeMessageAndGenerateProposal({
    required String message,
  }) async {
    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey',
    );

    final prompt =
        '''
Aşağıda bir müşterinin hizmet talebi mesajı var. 
Sen bir profesyonel teklif oluşturma asistanısın. 
Sadece aşağıdaki gibi, JSON formatında yanıt ver:

{
  "customer": "(müşteri adı ve soyadı)",
  "request": "(iş talebinin kısa özeti)",
  "description": "(müşteriye sunulacak, GİRİŞ, GELİŞME, SONUÇ başlıklarıyla, açıklayıcı ve kibar bir teklif metni)"
}

GİRİŞ: Selam ve başvuruya teşekkür et.
GELİŞME: Müşterinin isteğini ve teklif edilen hizmeti detaylandır.
SONUÇ: İletişim ve kapanış cümlesi yaz. Fiyatı belirtme.
Metin Türkçe ve profesyonel olsun.

Mesaj:
$message
''';

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        "contents": [
          {
            "parts": [
              {"text": prompt},
            ],
          },
        ],
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final candidates = data['candidates'];
      if (candidates != null && candidates.isNotEmpty) {
        var content =
            candidates[0]?['content']?['parts']?[0]?['text']
                ?.toString()
                .trim() ??
            '';
        final regex = RegExp(r'```(?:json)?([\s\S]*?)```', multiLine: true);
        final match = regex.firstMatch(content);
        if (match != null) {
          content = match.group(1)?.trim() ?? content.trim();
        } else {
          final jsonMatch = RegExp(r'(\{[\s\S]*\})').firstMatch(content);
          if (jsonMatch != null) {
            content = jsonMatch.group(1)!.trim();
          }
        }
        try {
          final parsed = jsonDecode(content);
          return {
            "customer": parsed["customer"] ?? "",
            "request": parsed["request"] ?? "",
            "description": parsed["description"] ?? "",
          };
        } catch (e) {
          print('Gemini JSON parse hatası: $e\nGelen içerik: $content');
          throw Exception('Gemini yanıtı beklenen JSON formatında değil.');
        }
      } else {
        throw Exception('Gemini API: Yanıt alınamadı!');
      }
    } else {
      print('Gemini response error: ${response.statusCode} - ${response.body}');
      throw Exception('Gemini mesaj analiz ve teklif üretilemedi');
    }
  }
}
