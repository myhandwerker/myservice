import 'package:flutter/material.dart';
import 'gemini_service.dart';

class AiProposalSuggestion extends StatefulWidget {
  const AiProposalSuggestion({super.key});

  @override
  State<AiProposalSuggestion> createState() => _AiProposalSuggestionState();
}

class _AiProposalSuggestionState extends State<AiProposalSuggestion> {
  final _controller = TextEditingController();
  String _result = '';
  bool _loading = false;

  Future<void> _getProposal() async {
    if (_controller.text.trim().isEmpty) return;
    setState(() {
      _loading = true;
      _result = '';
    });
    try {
      final res = await GeminiService.analyzeMessageAndGenerateProposal(
        message: _controller.text,
      );
      setState(() {
        _result =
            'Müşteri: ${res["customer"]}\nİstek: ${res["request"]}\nAçıklama:\n${res["description"]}';
      });
    } catch (e) {
      setState(() {
        _result = 'Hata: $e';
      });
    }
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Teklif Önerisi')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Müşteri mesajını girin ve AI teklif önerisi alın:'),
            const SizedBox(height: 10),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Müşteri mesajı...',
              ),
              minLines: 3,
              maxLines: 6,
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _loading ? null : _getProposal,
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('AI ile Teklif Oluştur'),
            ),
            const SizedBox(height: 20),
            if (_result.isNotEmpty) SelectableText(_result),
          ],
        ),
      ),
    );
  }
}
