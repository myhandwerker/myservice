import 'package:flutter/material.dart';
import '../../utils/constants.dart';
import '../../models/proposal.dart';
import 'proposal_list.dart'; // ProposalForm için
import 'gemini_service.dart'; // GeminiService için

class ProposalFromMessagePage extends StatefulWidget {
  const ProposalFromMessagePage({super.key});

  @override
  State<ProposalFromMessagePage> createState() =>
      _ProposalFromMessagePageState();
}

class _ProposalFromMessagePageState extends State<ProposalFromMessagePage> {
  final TextEditingController _messageController = TextEditingController();

  String customer = "";
  String request = "";
  String description = "";
  double? amount;
  bool loadingAI = false;

  Future<void> _analyzeAndFill() async {
    if (_messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Lütfen müşteri mesajını girin!")),
      );
      return;
    }
    setState(() => loadingAI = true);

    try {
      final result = await GeminiService.analyzeMessageAndGenerateProposal(
        message: _messageController.text,
      );
      setState(() {
        customer = result['customer'] ?? "";
        request = result['request'] ?? "";
        description = result['description'] ?? "";
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("AI analizi başarısız: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
    setState(() => loadingAI = false);
  }

  void _goToProposalForm(BuildContext context) async {
    final Proposal? newProposal = await showDialog(
      context: context,
      builder: (context) => ProposalForm(
        initialProposal: Proposal(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: request.isNotEmpty ? request : "Teklif",
          customer: customer,
          amount: amount ?? 0,
          status: 'Beklemede',
          date: DateTime.now(),
          description: description,
          request: request,
        ),
      ),
    );
    if (newProposal != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Teklif başarıyla oluşturuldu!")),
      );
      Navigator.of(context).pop(); // Ana sayfaya dön
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Mesajdan Teklif Oluştur")),
      backgroundColor: AppColors.background,
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text(
              "Müşteriden gelen mesajı aşağıya yapıştır:",
              style: TextStyle(color: AppColors.white),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _messageController,
              minLines: 6,
              maxLines: 12,
              style: const TextStyle(color: AppColors.white),
              decoration: const InputDecoration(
                hintText: "Müşteri mesajını buraya yapıştırın...",
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              icon: loadingAI
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppColors.background,
                      ),
                    )
                  : const Icon(Icons.auto_fix_high),
              label: const Text("AI ile Teklif Alanlarını Doldur"),
              onPressed: loadingAI ? null : _analyzeAndFill,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.yellowAccent,
                foregroundColor: AppColors.background,
              ),
            ),
            const SizedBox(height: 20),
            if (customer.isNotEmpty ||
                request.isNotEmpty ||
                description.isNotEmpty)
              Card(
                color: AppColors.background,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: const BorderSide(color: AppColors.yellowAccent),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (customer.isNotEmpty)
                        Text(
                          "Müşteri: $customer",
                          style: const TextStyle(color: AppColors.yellowAccent),
                        ),
                      if (request.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          "İstek: $request",
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                      if (description.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(
                          "Açıklama (AI):",
                          style: const TextStyle(color: AppColors.yellowAccent),
                        ),
                        Text(
                          description,
                          style: const TextStyle(color: Colors.white),
                        ),
                      ],
                      const SizedBox(height: 8),
                      TextField(
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: AppColors.white),
                        decoration: const InputDecoration(
                          labelText: "Tutar (₺)",
                          labelStyle: TextStyle(color: AppColors.yellowAccent),
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (v) =>
                            amount = double.tryParse(v.replaceAll(',', '.')),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        onPressed:
                            (customer.isNotEmpty &&
                                request.isNotEmpty &&
                                description.isNotEmpty)
                            ? () => _goToProposalForm(context)
                            : null,
                        child: const Text("Teklif Formuna Aktar"),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
