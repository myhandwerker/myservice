import 'package:flutter/material.dart';
import '../../models/proposal.dart';
import '../../utils/constants.dart';
import 'proposal_form_message_ai.dart'; // AI ile teklif için

Future<String> generateProposalDescriptionAI({
  required String customer,
  required String request,
  required double amount,
}) async {
  await Future.delayed(const Duration(seconds: 1));
  return '''
GİRİŞ:
Sayın $customer, teklif talebiniz için teşekkür ederiz.

GELİŞME:
İsteğiniz: $request
Toplam fiyat: ₺${amount.toStringAsFixed(2)}
Tüm malzeme ve işçilik dahil, kaliteli ve zamanında teslimat sağlanacaktır.

SONUÇ:
Teklifimiz hakkında detaylı bilgi ve iletişim için her zaman ulaşabilirsiniz.
Saygılarımızla.
''';
}

class ProposalList extends StatefulWidget {
  const ProposalList({super.key});

  @override
  State<ProposalList> createState() => _ProposalListState();
}

class _ProposalListState extends State<ProposalList> {
  final List<Proposal> proposals = [
    Proposal(
      id: '1',
      title: 'Web Sitesi Tasarımı',
      customer: 'Ali Yılmaz',
      amount: 25000.0,
      status: 'Beklemede',
      date: DateTime(2025, 6, 1),
      description: 'Kurumsal bir web sitesi tasarımı için teklif.',
      request: 'Kurumsal web sitesi hazırlanacak.',
    ),
    Proposal(
      id: '2',
      title: 'Mobil Uygulama',
      customer: 'Ayşe Demir',
      amount: 50000.0,
      status: 'Kabul Edildi',
      date: DateTime(2025, 5, 20),
      description: 'Android ve iOS için mobil uygulama geliştirme teklifi.',
      request: 'Restoranlar için sipariş uygulaması.',
    ),
  ];

  void _addProposal() async {
    final Proposal? newProposal = await showDialog(
      context: context,
      builder: (context) => ProposalForm(),
    );
    if (newProposal != null) {
      setState(() {
        proposals.add(newProposal);
      });
    }
  }

  void _editProposal(Proposal proposal) async {
    final Proposal? updatedProposal = await showDialog(
      context: context,
      builder: (context) => ProposalForm(initialProposal: proposal),
    );
    if (updatedProposal != null) {
      setState(() {
        final idx = proposals.indexWhere((p) => p.id == proposal.id);
        proposals[idx] = updatedProposal;
      });
    }
  }

  void _removeProposal(Proposal proposal) {
    setState(() {
      proposals.removeWhere((p) => p.id == proposal.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Teklif silindi: ${proposal.title}'),
        backgroundColor: AppColors.yellowAccent,
        action: SnackBarAction(
          label: 'Geri Al',
          textColor: AppColors.background,
          onPressed: () {
            setState(() {
              proposals.add(proposal);
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text(
              "Teklifler",
              style: const TextStyle(
                color: AppColors.yellowAccent,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: proposals.isEmpty
                ? const Center(
                    child: Text(
                      "Henüz teklif yok.",
                      style: TextStyle(color: Colors.white54, fontSize: 18),
                    ),
                  )
                : ListView.separated(
                    itemCount: proposals.length,
                    separatorBuilder: (_, __) =>
                        Divider(color: AppColors.yellowAccent),
                    itemBuilder: (context, i) {
                      final p = proposals[i];
                      return ListTile(
                        leading: const Icon(
                          Icons.description,
                          color: AppColors.yellowAccent,
                        ),
                        title: Text(
                          p.title,
                          style: const TextStyle(color: AppColors.white),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Müşteri: ${p.customer}',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            Text(
                              'Tutar: ₺${p.amount.toStringAsFixed(2)}',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            Text(
                              'Durum: ${p.status}',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            Text(
                              'Tarih: ${p.date.day}.${p.date.month}.${p.date.year}',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Müşteri isteği: ${p.request}',
                              style: const TextStyle(color: Colors.white70),
                            ),
                            Text(
                              p.description,
                              style: const TextStyle(
                                color: Colors.white60,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                        trailing: IconButton(
                          icon: const Icon(
                            Icons.edit,
                            color: AppColors.yellowAccent,
                          ),
                          onPressed: () => _editProposal(p),
                        ),
                        onLongPress: () => _removeProposal(p),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            backgroundColor: AppColors.yellowAccent,
            foregroundColor: AppColors.background,
            onPressed: _addProposal,
            heroTag: "normalTeklif",
            child: const Icon(Icons.add),
            tooltip: "Yeni Teklif Ekle",
          ),
          const SizedBox(height: 12),
          FloatingActionButton(
            backgroundColor: Colors.blueAccent,
            foregroundColor: Colors.white,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const ProposalFromMessagePage(),
                ),
              );
            },
            heroTag: "mesajdanTeklif",
            child: const Icon(Icons.auto_fix_high),
            tooltip: "Mesajdan Teklif Oluştur",
          ),
        ],
      ),
    );
  }
}

// --- ProposalForm (tam ve eksiksiz) ---
class ProposalForm extends StatefulWidget {
  final Proposal? initialProposal;
  const ProposalForm({super.key, this.initialProposal});

  @override
  State<ProposalForm> createState() => _ProposalFormState();
}

class _ProposalFormState extends State<ProposalForm> {
  final _formKey = GlobalKey<FormState>();
  late String title;
  late String customer;
  late double amount;
  late String status;
  late DateTime date;
  String description = "";
  String request = "";

  bool loadingAI = false;

  final List<String> statusOptions = [
    'Beklemede',
    'Kabul Edildi',
    'Reddedildi',
  ];

  @override
  void initState() {
    super.initState();
    title = widget.initialProposal?.title ?? '';
    customer = widget.initialProposal?.customer ?? '';
    amount = widget.initialProposal?.amount ?? 0;
    status = widget.initialProposal?.status ?? statusOptions.first;
    date = widget.initialProposal?.date ?? DateTime.now();
    description = widget.initialProposal?.description ?? '';
    request = widget.initialProposal?.request ?? '';
  }

  Future<void> _generateAIDescription() async {
    if (request.isEmpty || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "AI açıklaması için önce müşteri isteği ve tutar girin!",
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }
    setState(() => loadingAI = true);
    try {
      final result = await generateProposalDescriptionAI(
        customer: customer,
        request: request,
        amount: amount,
      );
      setState(() {
        description = result;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("AI açıklaması alınamadı: $e"),
          backgroundColor: Colors.red,
        ),
      );
    }
    setState(() => loadingAI = false);
  }

  @override
  Widget build(BuildContext context) {
    final descController = TextEditingController(text: description);
    return AlertDialog(
      backgroundColor: AppColors.background,
      title: Text(
        widget.initialProposal == null ? "Yeni Teklif" : "Teklif Düzenle",
        style: const TextStyle(color: AppColors.yellowAccent),
      ),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                initialValue: title,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Başlık"),
                validator: (value) =>
                    (value == null || value.isEmpty) ? "Başlık giriniz" : null,
                onSaved: (value) => title = value ?? '',
                onChanged: (v) => title = v,
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: customer,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Müşteri"),
                validator: (value) =>
                    (value == null || value.isEmpty) ? "Müşteri giriniz" : null,
                onSaved: (value) => customer = value ?? '',
                onChanged: (v) => customer = v,
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: amount == 0 ? '' : amount.toString(),
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Tutar (₺)"),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) return "Tutar giriniz";
                  final num? parsed = num.tryParse(value.replaceAll(',', '.'));
                  if (parsed == null || parsed <= 0)
                    return "Geçerli bir tutar giriniz";
                  return null;
                },
                onSaved: (value) =>
                    amount = double.tryParse(value!.replaceAll(',', '.')) ?? 0,
                onChanged: (v) =>
                    amount = double.tryParse(v.replaceAll(',', '.')) ?? 0,
              ),
              const SizedBox(height: 12),
              TextFormField(
                initialValue: request,
                style: const TextStyle(color: AppColors.white),
                decoration: const InputDecoration(labelText: "Müşteri İsteği"),
                validator: (value) => (value == null || value.isEmpty)
                    ? "Müşteri isteğini yazınız"
                    : null,
                onSaved: (value) => request = value ?? '',
                onChanged: (v) => request = v,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: status,
                items: statusOptions
                    .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                    .toList(),
                decoration: const InputDecoration(labelText: "Durum"),
                onChanged: (val) =>
                    setState(() => status = val ?? statusOptions.first),
                onSaved: (value) => status = value ?? statusOptions.first,
                dropdownColor: AppColors.background,
                style: const TextStyle(color: AppColors.white),
              ),
              const SizedBox(height: 12),
              ListTile(
                title: Text(
                  "Tarih: ${date.day}.${date.month}.${date.year}",
                  style: const TextStyle(color: Colors.white70),
                ),
                trailing: const Icon(
                  Icons.calendar_today,
                  color: AppColors.yellowAccent,
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: date,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) setState(() => date = picked);
                },
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: descController,
                      minLines: 4,
                      maxLines: 8,
                      style: const TextStyle(color: AppColors.white),
                      decoration: const InputDecoration(
                        labelText: "Açıklama (AI ile doldurulabilir)",
                      ),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? "Açıklama giriniz" : null,
                      onSaved: (v) => description = v ?? "",
                      onChanged: (v) => description = v,
                    ),
                  ),
                  IconButton(
                    icon: loadingAI
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: AppColors.yellowAccent,
                              strokeWidth: 3,
                            ),
                          )
                        : const Icon(
                            Icons.auto_fix_high,
                            color: AppColors.yellowAccent,
                          ),
                    tooltip: "AI ile Açıklama Oluştur",
                    onPressed: loadingAI ? null : _generateAIDescription,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          child: const Text(
            "İptal",
            style: TextStyle(color: AppColors.yellowAccent),
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.yellowAccent,
            foregroundColor: AppColors.background,
          ),
          child: Text(widget.initialProposal == null ? "Ekle" : "Kaydet"),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              _formKey.currentState!.save();
              final proposal = Proposal(
                id:
                    widget.initialProposal?.id ??
                    DateTime.now().millisecondsSinceEpoch.toString(),
                title: title,
                customer: customer,
                amount: amount,
                status: status,
                date: date,
                description: description,
                request: request,
              );
              Navigator.of(context).pop(proposal);
            }
          },
        ),
      ],
    );
  }
}
