// lib/main.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Provider paketi import edildi

// Uygulama genelindeki sabitler ve temalar
import 'utils/constants.dart';

// Müşteri Modülü
import 'modules/customers/customer_list.dart';
import 'modules/customers/customer_model.dart';
import 'modules/customers/customer_provider.dart'; // CustomerProvider import edildi

// Diğer Modüller (Emin olun bu dosyalar mevcut ve doğru yolda)
import 'modules/proposals/proposal_list.dart';
import 'modules/tasks/task_list.dart';
import 'modules/invoices/invoice_list.dart';
import 'modules/reports/analytics.dart';
import 'modules/employees/employee_list.dart';
import 'modules/integration/integration_service.dart';
import 'modules/security/security_service.dart';
import 'modules/feedback/feedback_list.dart';
import 'modules/offline/offline_service.dart';

// Ayarlar Modülü
import 'modules/settings/settings_home_page.dart';
import 'modules/settings/company_settings_model.dart';
import 'modules/settings/theme_notifier.dart';
import 'modules/settings/company_customization_page.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CustomerProvider()),
        // Buraya diğer provider'larınızı ekleyebilirsiniz (örn: InvoiceProvider, TaskProvider)
        // Eğer themeNotifier bir Change Notifier ise onu da buraya ekleyebilirsiniz,
        // ancak mevcut yapıda AnimatedBuilder ile kullanıldığı için doğrudan burada tanımlayacağız.
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Başlangıç şirket ayarları
  CompanySettings companySettings = CompanySettings(
    companyName: "Demo Şirketi",
    companyDescription: "Açıklamanızı buraya yazabilirsiniz.",
    logoPath: null,
    themeColor: AppColors.yellowAccent, // Başlangıç tema rengi
  );

  // Tema değişikliklerini dinlemek için ThemeNotifier
  late ThemeNotifier themeNotifier;

  @override
  void initState() {
    super.initState();
    // ThemeNotifier'ı başlangıçta varsayılan veya kaydedilmiş tema ile başlatın
    themeNotifier = ThemeNotifier(
      ThemeData(
        scaffoldBackgroundColor: AppColors.background,
        primaryColor: AppColors.yellowAccent,
        colorScheme: const ColorScheme.dark(
          surface: AppColors.background,
          primary: AppColors.yellowAccent, // Ana renk
          secondary: AppColors.yellowAccent, // İkincil vurgu rengi
          onPrimary: AppColors.white,
          onSurface: AppColors.white,
          background: AppColors.background, // Uygulama genel arka planı
          error: AppColors.error, // Hata rengi
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.background,
          foregroundColor: AppColors.yellowAccent,
          elevation: 0,
        ),
        iconTheme: const IconThemeData(color: AppColors.yellowAccent),
        inputDecorationTheme: const InputDecorationTheme(
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.yellowAccent),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: AppColors.yellowAccent, width: 2),
          ),
          labelStyle: TextStyle(color: AppColors.yellowAccent),
          hintStyle: TextStyle(color: AppColors.yellowAccent),
        ),
        textTheme:
            const TextTheme(
              bodyMedium: TextStyle(color: AppColors.white),
              bodyLarge: TextStyle(color: AppColors.white),
              bodySmall: TextStyle(color: AppColors.white),
            ).apply(
              bodyColor: AppColors.white, // Varsayılan metin rengi
              displayColor: AppColors.white, // Başlık metin rengi
            ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: AppColors.background,
          selectedItemColor: AppColors.yellowAccent,
          unselectedItemColor: Colors.white54,
        ),
        drawerTheme: const DrawerThemeData(
          backgroundColor: AppColors.background,
        ),
        dividerColor: AppColors.yellowAccent,
      ),
    );
  }

  // Şirket ayarları değiştiğinde çağrılan fonksiyon
  void _updateCompanySettings(CompanySettings newSettings) {
    setState(() {
      companySettings = newSettings;
      // Tema rengi değiştiyse tüm uygulamaya uygula
      themeNotifier.updateColor(
        newSettings.themeColor ?? AppColors.yellowAccent,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // Burada geçici olarak bir örnek müşteri oluşturuyoruz.
    // Gerçek uygulamada bu müşteri veritabanından veya bir servis aracılığıyla gelecektir.
    // Bu sadece bir örnek, InvoiceList için varsayılan bir müşteri sağlamak içindir.
    final Customer sampleCustomer = Customer(
      id: 'sample_customer_id_for_main',
      name: 'Örnek Müşteri (Ana Ekran)',
      address: 'Örnek Adres, Şehir',
      phone: '1234567890',
      email: 'sample@example.com',
      materials: const [], // Boş liste varsayılan olarak
      workHours: const [], // Boş liste varsayılan olarak
    );

    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) => MaterialApp(
        title: 'MyService App', // Uygulama başlığı
        theme: themeNotifier.themeData, // Dinamik tema
        home: MainScreen(
          companySettings: companySettings,
          onCompanySettingsChanged: _updateCompanySettings,
          currentCustomer: sampleCustomer, // Buraya sampleCustomer'ı geçiyoruz
        ),
        debugShowCheckedModeBanner: false,
        routes: {
          // Rota tanımları (genellikle bu rotalar daha organize bir yerde tutulur)
          '/customers': (ctx) => const CustomerListScreen(),
          '/proposals': (ctx) => const ProposalList(),
          '/tasks': (ctx) => const TaskList(),
          // '/invoices' rotası varsa, customer parametresi olmadan çağrılırsa hata verir.
          // O yüzden doğrudan home'dan veya başka bir yerden parametre ile geçmek daha güvenli.
          // '/invoices': (ctx) => InvoiceList(customer: sampleCustomer), // Örnek olarak
          '/reports': (ctx) => const AnalyticsPage(),
          '/employees': (ctx) => const EmployeeList(),
          '/integration': (ctx) => const IntegrationService(),
          '/security': (ctx) => const SecurityService(),
          '/feedback': (ctx) => const FeedbackList(),
          '/offline': (ctx) => const OfflineService(),
          '/settings': (ctx) => SettingsHomePage(
            companySettings: companySettings,
            onCompanySettingsChanged: _updateCompanySettings,
          ),
        },
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  final CompanySettings companySettings;
  final void Function(CompanySettings) onCompanySettingsChanged;
  final Customer currentCustomer; // Yeni eklenen customer parametresi

  const MainScreen({
    super.key,
    required this.companySettings,
    required this.onCompanySettingsChanged,
    required this.currentCustomer, // Yeni eklenen parametre
  });

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0; // Şu anki seçili menü öğesinin indeksi

  // Tüm sayfa widget'larını içeren liste
  List<Widget> get _pages => [
    const CustomerListScreen(),
    const ProposalList(),
    const TaskList(),
    InvoiceList(
      customer:
          widget.currentCustomer, // InvoiceList'e müşteri parametresi geçiliyor
    ),
    const AnalyticsPage(),
    const EmployeeList(),
    const IntegrationService(),
    const SecurityService(),
    const FeedbackList(),
    const OfflineService(),
    SettingsHomePage(
      companySettings: widget.companySettings,
      onCompanySettingsChanged: widget.onCompanySettingsChanged,
    ),
  ];

  // Menü öğelerinin başlıkları
  final List<String> _titles = [
    "Müşteriler",
    "Teklifler",
    "Görevler",
    "Faturalar",
    "Raporlar",
    "Çalışanlar",
    "Entegrasyon",
    "Güvenlik",
    "Geri Bildirim",
    "Offline",
    "Ayarlar",
  ];

  // Menü öğelerinin ikonları
  final List<IconData> _icons = [
    Icons.people,
    Icons.lightbulb,
    Icons.check_circle,
    Icons.receipt_long,
    Icons.bar_chart,
    Icons.group,
    Icons.link,
    Icons.security,
    Icons.feedback,
    Icons.offline_bolt,
    Icons.settings,
  ];

  // Drawer (yan menü) öğelerini oluşturan metot
  List<Widget> _drawerItems() {
    return List.generate(_titles.length, (i) {
      if (_titles[i] == "Ayarlar") {
        return ExpansionTile(
          leading: Icon(_icons[i], color: Theme.of(context).iconTheme.color),
          title: Text(
            _titles[i],
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          initiallyExpanded: false,
          children: [
            ListTile(
              leading: Icon(
                Icons.tune,
                color: Theme.of(context).iconTheme.color,
              ),
              title: Text(
                'Şirket Özelleştirmeleri',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              onTap: () async {
                Navigator.of(context).pop(); // Drawer'ı kapat
                final updatedSettings = await Navigator.push<CompanySettings>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CompanyCustomizationPage(
                      companySettings: widget.companySettings,
                      onCompanySettingsChanged: widget.onCompanySettingsChanged,
                    ),
                  ),
                );
                // Ayarlar güncellenirse, ana ekran state'ini de güncelle
                if (updatedSettings != null) {
                  widget.onCompanySettingsChanged(updatedSettings);
                }
                // setstate burada gerekmez çünkü onCompanySettingsChanged zaten üst widget'ı tetikler.
              },
            ),
            // Buraya başka ayar alt öğeleri eklenebilir
          ],
        );
      }
      return ListTile(
        leading: Icon(_icons[i], color: Theme.of(context).iconTheme.color),
        title: Text(_titles[i], style: Theme.of(context).textTheme.bodyMedium),
        selected: _currentIndex == i, // Seçili öğeyi vurgula
        onTap: () {
          setState(() => _currentIndex = i); // Seçimi güncelle
          Navigator.of(context).pop(); // Drawer'ı kapat
        },
      );
    });
  }

  // Alt navigasyon çubuğunda gösterilecek maksimum sekme sayısı
  static const int maxBottomTabs = 5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _titles[_currentIndex],
          style: AppTextStyles.headlineSmall.copyWith(
            color: AppColors.yellowAccent,
          ), // Temadan çekilen renk ile başlık
        ),
        backgroundColor: AppColors.background, // AppBar arka plan rengi
        iconTheme: const IconThemeData(
          color: AppColors.yellowAccent,
        ), // AppBar ikon rengi
      ),
      drawer: Drawer(
        backgroundColor: AppColors.background, // Drawer arka plan rengi
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color:
                    widget.companySettings.themeColor ??
                    AppColors.yellowAccent, // Şirket temasından veya varsayılan
              ),
              child: Row(
                children: [
                  // Şirket logosunu göster
                  if (widget.companySettings.logoPath != null &&
                      File(widget.companySettings.logoPath!).existsSync())
                    Image.file(
                      File(widget.companySettings.logoPath!),
                      width: 48,
                      height: 48,
                      fit: BoxFit.cover,
                    )
                  else // Logo yoksa varsayılan ikon
                    const Icon(
                      Icons.business,
                      size: 48,
                      color: AppColors
                          .primary, // Sarı logonun üzerinde daha iyi görünür
                    ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.companySettings.companyName,
                          style: AppTextStyles.headline6.copyWith(
                            color: AppColors
                                .primary, // Sarı üzerinde iyi görünen renk
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (widget.companySettings.companyDescription != null &&
                            widget
                                .companySettings
                                .companyDescription!
                                .isNotEmpty)
                          Text(
                            widget.companySettings.companyDescription!,
                            style: AppTextStyles.bodySmall.copyWith(
                              color: AppColors.primary.withOpacity(0.8),
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Drawer öğelerini ekle
            ..._drawerItems(),
          ],
        ),
      ),
      body: _pages[_currentIndex], // Seçili sayfayı göster
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex < maxBottomTabs ? _currentIndex : 0,
        onTap: (i) {
          setState(() => _currentIndex = i);
        },
        type: BottomNavigationBarType.fixed, // Tüm öğeleri göster
        backgroundColor: AppColors.background, // BottomNav arka plan rengi
        selectedItemColor: AppColors.yellowAccent, // Seçili öğe rengi
        unselectedItemColor:
            AppColors.textSecondary, // Seçili olmayan öğe rengi
        items: List.generate(
          maxBottomTabs,
          (i) =>
              BottomNavigationBarItem(icon: Icon(_icons[i]), label: _titles[i]),
        ),
      ),
    );
  }
}
